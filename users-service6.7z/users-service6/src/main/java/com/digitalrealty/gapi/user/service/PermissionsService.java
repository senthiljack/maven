package com.digitalrealty.gapi.user.service;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import com.digitalrealty.gapi.user.model.payloadmodel.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.common.context.ContextHeaders;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.CommonExceptionUtil;
import com.digitalrealty.gapi.user.configuration.UserConfig;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
@Slf4j
public class PermissionsService {

	private final WebClient webClient;

	private final UserConfig userConfig;

	private final RedisCacheService redisCacheService;

	private final JwtConfig jwtConfig;

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public void validateRoles(RoleValidationRequest roleValidationRequest) {
		webClient.post()
				.uri(userConfig.getPermissionServiceURL() + "/roles/validate")
				.header("Authorization", "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(roleValidationRequest), RoleCheckPermissionsRequest.class)
				.retrieve()
				.toBodilessEntity()
				.doOnError(throwable -> {
					CommonException ce = CommonExceptionUtil.processOtherGapiServiceException(throwable);
					log.error("RoleValidationRequest to Permission MC has failed", ce);
					throw ce;
				})
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public void isAuthorized(RoleCheckPermissionsRequest roleCheckPermissionsRequest) {
		webClient.post()
				.uri(userConfig.getPermissionServiceURL() + "/permissions/action/validate")
				.header("Authorization", "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(roleCheckPermissionsRequest), RoleCheckPermissionsRequest.class)
				.retrieve()
				.toBodilessEntity()
				.doOnError(throwable -> {
					CommonException ce = CommonExceptionUtil.processOtherGapiServiceException(throwable);
					log.error("ActionValidation request to Permission MC has failed", ce);
					throw ce;
				})
				.block();
	}

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public ApproverValidationResponse validateApprovers(ApproverValidationRequest approverValidationRequest) {
		return webClient.post()
				.uri(userConfig.getPermissionServiceURL() + "/privileges/validate-approvers")
				.header("Authorization", "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(BodyInserters.fromValue(approverValidationRequest))
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.SYSTEM)))
				.bodyToMono(ApproverValidationResponse.class)
				.doOnError(throwable -> {
					CommonException ce = CommonExceptionUtil.processOtherGapiServiceException(throwable);
					log.error("validateApprovers to Permission MC has failed", ce);
					throw ce;
				})
				.block();
	}
}
