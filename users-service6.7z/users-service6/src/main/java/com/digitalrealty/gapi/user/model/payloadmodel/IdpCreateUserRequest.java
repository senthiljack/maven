package com.digitalrealty.gapi.user.model.payloadmodel;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IdpCreateUserRequest {

	private String id;

	private UUID externalId;

	private String userName;

	@Builder.Default
	private String preferredLanguage = "undefined";

	private String emailAddress;

}
