package com.digitalrealty.gapi.user.service;

import java.util.List;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.user.entity.UserAccountRoleEntity;
import com.digitalrealty.gapi.user.mapper.UserAccountRoleMapper;
import com.digitalrealty.gapi.user.model.IUserAccountRole;
import com.digitalrealty.gapi.user.model.UserAccountRole;
import com.digitalrealty.gapi.user.repository.UserAccountRoleRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class UserAccountRoleDBService {

	private final UserAccountRoleRepository userAccountRoleRepository;

	private final UserAccountRoleMapper userAccountRoleMapper;

	public UserAccountRole createUserAccountRole(UserAccountRole userAccountRole) {
		UserAccountRoleEntity userAccountRoleEntity = userAccountRoleMapper.map(userAccountRole);
		return userAccountRoleMapper.map(userAccountRoleRepository.save(userAccountRoleEntity));
	}

	public List<IUserAccountRole> findByRoleId(UUID roleId) {
		return userAccountRoleRepository.findByRoleId(roleId);
	}

	public List<IUserAccountRole> findByUserAccountId(UUID userAccountId) {
		return userAccountRoleRepository.findByUserAccountId(userAccountId);
	}

	public List<UUID> findIdsByUserAccountId(UUID userAccountId) {
		return userAccountRoleRepository.findIdsByUserAccountId(userAccountId.toString());
	}

	public List<UUID> findUserAccountIdsByRoleId(UUID roleId) {
		return userAccountRoleRepository.findUserAccountIdsByRoleId(roleId);
	}

	public List<IUserAccountRole> findByAssetIdIn(UUID userAccountId, List<String> assetIdd) {
		return userAccountRoleRepository.findUserAccountIdsByAssetIdIn(userAccountId, assetIdd);
	}

}
