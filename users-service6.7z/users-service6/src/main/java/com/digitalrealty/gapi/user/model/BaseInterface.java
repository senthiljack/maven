package com.digitalrealty.gapi.user.model;

import java.time.Instant;
import java.util.UUID;

public interface BaseInterface {

	UUID getId();

	String getCreatedBy();

	Instant getCreatedDate();

	String getLastModifiedBy();

	Instant getLastModifiedDate();

	Integer getVersion();
}
