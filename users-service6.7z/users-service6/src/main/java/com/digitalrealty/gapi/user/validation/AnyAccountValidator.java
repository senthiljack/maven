package com.digitalrealty.gapi.user.validation;

import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanWrapperImpl;

import com.digitalrealty.gapi.user.model.payloadmodel.RoleAssets;

public class AnyAccountValidator implements ConstraintValidator<AnyAccountMatch, Object> {

	private String anyAccountField;
	private String legalEntityField;
	private String associationField;

	@Override
	public void initialize(AnyAccountMatch constraintAnnotation) {
		this.anyAccountField = constraintAnnotation.anyAccountField();
		this.legalEntityField = constraintAnnotation.legalEntityField();
		this.associationField = constraintAnnotation.associationField();
	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		Boolean anyAccountValue = (Boolean) new BeanWrapperImpl(value).getPropertyValue(anyAccountField);
		String legalEntity = (String) new BeanWrapperImpl(value).getPropertyValue(legalEntityField);
		List<RoleAssets> associations = (List<RoleAssets>) new BeanWrapperImpl(value).getPropertyValue(associationField);

		return ((!anyAccountValue && !associations.isEmpty() && !StringUtils.isEmpty(legalEntity)) || (anyAccountValue && associations.isEmpty() && StringUtils.isEmpty(legalEntity)));
	}
}