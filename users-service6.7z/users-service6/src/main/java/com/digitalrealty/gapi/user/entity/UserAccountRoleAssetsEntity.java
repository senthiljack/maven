package com.digitalrealty.gapi.user.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true, exclude = { "userAccount" })
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Audited
@Table(name = "user_account_role_assets")
public class UserAccountRoleAssetsEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Type(type = "uuid-char")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_account_id", nullable = false)
	private UserAccountEntity userAccount;

	@OneToMany(mappedBy = "userAccountRoleAssets", orphanRemoval = true, cascade = CascadeType.ALL)
	private Set<UserAccountAssetEntity> userAccountAssets;

	@OneToOne(mappedBy = "userAccountRoleAssets", orphanRemoval = true, cascade = CascadeType.ALL)
	private UserAccountRoleEntity userAccountRole;

}
