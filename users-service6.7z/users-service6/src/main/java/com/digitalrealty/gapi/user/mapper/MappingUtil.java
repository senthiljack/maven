package com.digitalrealty.gapi.user.mapper;

import java.util.UUID;

import org.mapstruct.Named;
import org.springframework.stereotype.Component;

import com.digitalrealty.gapi.user.entity.UserAccountEntity;
import com.digitalrealty.gapi.user.entity.UserAccountRoleAssetsEntity;
import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.repository.UserAccountRepository;
import com.digitalrealty.gapi.user.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class MappingUtil {

	private final UserRepository userRepository;

	private final UserAccountRepository userAccountRepository;

	@Named("getUserByUserId")
	public UserEntity getUserByUserId(UUID userId) {
		return userRepository.findById(userId).get();
	}

	@Named("getUserAccountByUserAccountId")
	public UserAccountEntity getUserAccountByUserAccountId(UUID userAccountId) {
		return userAccountRepository.findById(userAccountId).get();
	}

	@Named("getUserAccountRoleAssetById")
	public UserAccountRoleAssetsEntity getUserAccountRoleAssetById(UUID userAccountRoleAssetsId) {
		return userAccountRepository.findRoleAssetsByRoleAssetsId(userAccountRoleAssetsId.toString());
	}

}