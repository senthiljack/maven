package com.digitalrealty.gapi.user.model.snow;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserSysIdByEmail {

	private String sys_id;

	private String company;

	private String first_name;

	private String email;

	private String last_name;

	private String location;

}
