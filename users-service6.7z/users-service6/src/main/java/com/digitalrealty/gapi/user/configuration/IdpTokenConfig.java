package com.digitalrealty.gapi.user.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
import lombok.NoArgsConstructor;

@Configuration
@ConfigurationProperties(prefix = "token")
@NoArgsConstructor
@Data
public class IdpTokenConfig {
	private String idpClientId;
	private String idpClientSecret;
	private String idpGrantType;
}
