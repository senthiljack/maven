package com.digitalrealty.gapi.user.model.payloadmodel;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ActionValidationResponse {

	private Boolean isSuper;

	private UUID userId;

	private UserAccountAssociations associations;

}
