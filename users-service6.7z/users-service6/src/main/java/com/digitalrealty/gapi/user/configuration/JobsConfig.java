package com.digitalrealty.gapi.user.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import lombok.Data;
import lombok.NoArgsConstructor;

@Validated
@Configuration
@ConfigurationProperties(prefix = "jobs")
@NoArgsConstructor
@Data
public class JobsConfig {

	private String manageExecutionIdSchedule;

	private String resetExecutionIdSchedule;

	private String removeSuspendedSchedule;

	private int daysAfterAccountDeletion;

	private int manageExecutionIdsBatchSize;

	private int resetExecutionIdsTimeWindowSec;

}