package com.digitalrealty.gapi.user.model.snow;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UContactRef1 {

	private String link;

	private String value;

}
