package com.digitalrealty.gapi.user.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.digitalrealty.gapi.user.entity.UserAccountEntity;
import com.digitalrealty.gapi.user.entity.UserAccountRoleAssetsEntity;
import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;

@Repository
public interface UserAccountRepository extends CrudRepository<UserAccountEntity, UUID> {

	List<UserAccountEntity> findByIdIn(List<UUID> userIds);

	UserAccountEntity findByLegalEntityKeyAndUserId(String legalEntityKey, UUID userId);

	List<UserAccountEntity> findByLegalEntityKey(String legalEntityKey);

	List<UserAccountEntity> findByIdInAndStatus(List<UUID> userAccountIds, UserAccountStatus status);

	List<UserAccountEntity> findByUserId(UUID userId);

	Page<UserAccountEntity> findByUserIdIn(List<UUID> userIds, Pageable pageable);

	@Query(value = "SELECT * FROM user_gapi.user_account ua, user_gapi.users uu WHERE uu.id = ua.user_id AND uu.email = ?1 AND uu.status = 'ACTIVE' AND ua.status = 'ACTIVE' AND ua.approval_status = ?2", nativeQuery = true)
	List<UserAccountEntity> findByUserEmailAndApprovalStatus(String email, String approvalStatus);

	@Modifying
	@Query(value = "update user_gapi.user_account ua set ua.status='DELETED' where (EXTRACT (EPOCH FROM (CURRENT_TIMESTAMP()-ua.status_changed_date))) > ?1 and ua.status == 'AUTO_SUSPENDED'", nativeQuery = true)
	void deleteSuspendedAccounts(int daysAfterSuspension);

	@Query(value = "SELECT count (*) FROM user_gapi.user_account ua WHERE ua.legal_entity_key =?1 AND ua.status = 'ACTIVE'", nativeQuery = true)
	Integer getActiveUserCount(String legalEntityKey);

	@Query(value = "SELECT * FROM user_gapi.user_account_role_assets WHERE id = ?1", nativeQuery = true)
	UserAccountRoleAssetsEntity findRoleAssetsByRoleAssetsId(String id);

}