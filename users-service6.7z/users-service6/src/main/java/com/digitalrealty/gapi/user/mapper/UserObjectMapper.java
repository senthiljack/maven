package com.digitalrealty.gapi.user.mapper;

import static com.fasterxml.jackson.annotation.JsonCreator.Mode.PROPERTIES;

import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

public class UserObjectMapper extends ObjectMapper {
	private static final long serialVersionUID = 1L;

	public UserObjectMapper() {
		setSerializationInclusion(JsonInclude.Include.NON_NULL);
		configure(SerializationFeature.WRITE_ENUMS_USING_TO_STRING, true);
		configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
		configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);
		configure(DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS, false);
		configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		configure(DeserializationFeature.READ_ENUMS_USING_TO_STRING, true);
		configure(DeserializationFeature.ACCEPT_FLOAT_AS_INT, false);
		configure(SerializationFeature.INDENT_OUTPUT, false);
		configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
		configure(MapperFeature.ALLOW_COERCION_OF_SCALARS, false);
		enable(JsonReadFeature.ALLOW_UNESCAPED_CONTROL_CHARS.mappedFeature(), JsonReadFeature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER.mappedFeature());

		registerModule(new JavaTimeModule());
		registerModule(new ParameterNamesModule(PROPERTIES));
	}

	@Override
	public UserObjectMapper copy() {
		return this;
	}

	@Override
	public <T> T readValue(String content, Class<T> valueType) {
		try {
			return super.readValue(content, valueType);
		} catch (Exception exception) {
			throw new CommonException(ErrorCode.OBJECT_TO_JSON, exception);
		}
	}
}
