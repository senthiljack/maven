package com.digitalrealty.gapi.user.model;

import java.time.Instant;
import java.util.Set;
import java.util.UUID;

import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class UserAccount extends BaseModel {

	private String legalEntityKey;

	private UUID userId;

	private UserAccountStatus status;

	private ApprovalStatus approvalStatus;

	private Boolean defaultAccount;

	private Boolean anyAccount;

	private Instant statusChangedDate;

	private Set<UserAccountRoleAssets> associations;

}
