package com.digitalrealty.gapi.user.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;
import com.digitalrealty.gapi.user.exception.UserErrorCode;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountRoleResponse;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserAccountRoleService {

	private final SuperUserDBService superUserDBService;

	private final UserAccountDBService userAccountDBService;

	private final UserAccountRoleDBService userAccountRoleDBService;

	private final EncryptionService encryptionService;

	public void validateUserRole(UUID roleId) {
		List<UUID> userRoles = userAccountRoleDBService.findUserAccountIdsByRoleId(roleId);
		if (Objects.isNull(userRoles) || userRoles.size() == 0) {
			return;
		}

		List<UserAccount> activeUsers = userAccountDBService.findByIdsAndStatus(userRoles, UserAccountStatus.ACTIVE);
		if (Objects.isNull(activeUsers) || activeUsers.size() == 0) {
			return;
		}

		throw new CommonException(UserErrorCode.ROLE_ACTIVE);
	}

	public UserAccountRoleResponse getUserRoles() {
		String encryptedEmail = encryptionService.encryptEmail(ContextUtility.getUserEmail());
		List<UserAccount> userAccounts = userAccountDBService.findByUserEmailAndApprovalStatus(encryptedEmail, ApprovalStatus.APPROVED);

		boolean hasAny = (userAccounts.stream().filter(UserAccount::getAnyAccount).count() > 0);
		String superUser = superUserDBService.findByEmail(encryptedEmail);

		Optional<UserAccount> loggedAccount = userAccounts.stream().filter(userAcc -> userAcc.getLegalEntityKey().equals(ContextUtility.getLegalEntity())).findFirst();
		if (loggedAccount.isEmpty()) {
			if (StringUtils.isEmpty(superUser)) {
				throw new CommonException(UserErrorCode.USER_NOTFOUND);
			}

			return UserAccountRoleResponse.builder().superUser(true).anyAccount(hasAny).build();
		}

		List<UUID> userAccountRoles = userAccountRoleDBService.findIdsByUserAccountId(loggedAccount.get().getId());
		return UserAccountRoleResponse.builder().superUser(!StringUtils.isEmpty(superUser)).anyAccount(hasAny).userAccountRoles(userAccountRoles).build();
	}
}
