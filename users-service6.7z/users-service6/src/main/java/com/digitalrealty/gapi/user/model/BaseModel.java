package com.digitalrealty.gapi.user.model;

import java.time.Instant;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class BaseModel {

	private UUID id;

	@JsonIgnore
	private String createdBy;

	@JsonIgnore
	private Instant createdDate;

	@JsonIgnore
	private String lastModifiedBy;

	@JsonIgnore
	private Instant lastModifiedDate;

	private Integer version;
}
