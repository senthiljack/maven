package com.digitalrealty.gapi.user.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.digitalrealty.gapi.user.entity.UserAccountAssetEntity;
import com.digitalrealty.gapi.user.model.IUserAccountAsset;

@Repository
public interface UserAccountAssetRepository extends CrudRepository<UserAccountAssetEntity, UUID> {

	@Query(value = "SELECT user_account_asset.asset_id, user_account_asset.site_path, user_account_asset.user_account_role_assets_id FROM user_gapi.user_account_asset, user_gapi.user_account_role_assets WHERE " +
			"user_account_role_assets.id = user_account_asset.user_account_role_assets_id AND user_account_role_assets.user_account_id = ?1", nativeQuery = true)
	List<IUserAccountAsset> findByUserAccountId(UUID userAccountId);

	@Query(value = "SELECT user_account_asset.asset_id, user_account_asset.site_path, user_account_asset.user_account_role_assets_id FROM user_gapi.user_account_asset, user_gapi.user_account_role_assets WHERE " +
			"user_account_role_assets.id = user_account_asset.user_account_role_assets_id AND user_account_role_assets.user_account_id = ?1", nativeQuery = true)
	List<IUserAccountAsset> findIdsByUserAccountId(String userAccountId);
}
