package com.digitalrealty.gapi.user.model.payloadmodel;

import java.time.Instant;
import java.util.UUID;

import com.digitalrealty.gapi.user.enums.TermStatus;
import com.digitalrealty.gapi.user.enums.UserStatus;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserUpdateResponse {

	@JsonProperty("userId")
	@Schema(description = "User ID")
	private UUID id;

	@Schema(description = "First name")
	private String firstName;

	@Schema(description = "Last name")
	private String lastName;

	private String email;

	private String phone;

	@Schema(description = "User status indication (Draft, NotActive, Active)")
	private UserStatus status;

	private TermStatus termsAndConditionsStatus;

	private Instant termsAndConditionsDate;

	private String termsAndConditionsVersion;

	@Schema(description = "Last time the user status was changed")
	private Instant statusChangeDate;
}
