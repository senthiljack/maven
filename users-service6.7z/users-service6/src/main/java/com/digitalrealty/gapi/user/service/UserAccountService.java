package com.digitalrealty.gapi.user.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import com.digitalrealty.gapi.messaging.email.EmailType;
import com.digitalrealty.gapi.messaging.email.SendEmailMessage;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.messaging.user.MaintainUserMessage;
import com.digitalrealty.gapi.messaging.user.UserRequestType;
import com.digitalrealty.gapi.user.entity.UserAccountEntity;
import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;
import com.digitalrealty.gapi.user.exception.UserErrorCode;
import com.digitalrealty.gapi.user.mapper.UserAccountMapper;
import com.digitalrealty.gapi.user.mapper.UserMapper;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.model.payloadmodel.AssetModel;
import com.digitalrealty.gapi.user.model.payloadmodel.AssetValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.GetAccountsResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.RoleAssets;
import com.digitalrealty.gapi.user.model.payloadmodel.RoleValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountApprovalRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountApprovalResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssignmentRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssociationsResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountStatusRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountStatusResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountsRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.ValidateLegalEntitiesRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.ValidateLegalEntitiesResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.ValidateSiteRequest;
import com.digitalrealty.gapi.user.predicate.UserEntityPredicatesBuilder;
import com.digitalrealty.gapi.user.repository.DynamicUserRepository;
import com.digitalrealty.gapi.user.util.AssetUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserAccountService {

	private final AccountService accountService;

	private final PermissionsService permissionsService;

	private final UserAccountMapper userAccountMapper;

	private final UserMapper userMapper;

	private final AssetService assetService;

	private final DynamicUserRepository dynamicUserRepository;

	private final UserAccountDBService userAccountDBService;

	private final SuperUserDBService superUserDBService;

	private final UserDBService userDBService;

	private final EncryptionService encryptionService;

	private final JmsUserService jmsUserService;

	private final SendEmailMessage sendEmailMessage;

	private final EmailService emailService;

	public List<UserAccountAssociationsResponse> getUserAssignments(UUID targetUserId) {
		User dbTargetUser = userDBService.findById(targetUserId);
		if (Objects.isNull(dbTargetUser)) {
			throw new CommonException(UserErrorCode.USER_NOTFOUND);
		}

		ValidateLegalEntitiesResponse errorEntityKeys = accountService.validateLegalEntities(ValidateLegalEntitiesRequest.builder().legalEntityKeys(dbTargetUser.getUserAccounts().stream().map(UserAccount::getLegalEntityKey).collect(Collectors.toList())).build());

		return dbTargetUser.getUserAccounts().stream().filter(targetUserAccount -> !errorEntityKeys.erroredLegalEntityKeys.contains(targetUserAccount.getLegalEntityKey())).map(userAccount -> {
			UserAccountAssociationsResponse targetUserAssetRoles = new UserAccountAssociationsResponse();
			targetUserAssetRoles.setLegalEntityKey(userAccount.getLegalEntityKey());
			targetUserAssetRoles.setAssociations(
					userAccount.getAssociations().stream().map(association -> RoleAssets.builder()
							.role(association.getUserAccountRole().getRoleId())
							.assets(association.getUserAccountAssets().stream().map(UserAccountAsset -> new AssetModel(UserAccountAsset.getAssetId(), UserAccountAsset.getSitePath())).collect(Collectors.toList())).build()).collect(Collectors.toList()));

			return targetUserAssetRoles;
		}).collect(Collectors.toList());
	}

	public User manageAssignments(UUID targetUserId, Boolean includeInternal, UserAccountAssignmentRequest userAccountAssignmentRequest) {
		User targetUser = userDBService.findById(targetUserId);
		if (Objects.isNull(targetUser)) {
			throw new CommonException(UserErrorCode.USER_NOTFOUND);
		}

		Map<String, List<UUID>> targetUserAccountRoles = new HashMap<>();
		Map<String, List<AssetModel>> targetUserAccountAssets = new HashMap<>();
		List<AssetValidationRequest> targetUserAssetValidation = new ArrayList<AssetValidationRequest>();
		userAccountAssignmentRequest.getUserAccounts().forEach(targetUserAccount -> {
			List<UUID> roleIdList = new ArrayList<UUID>();

			targetUserAccount.getAssociations().forEach(targetUserAssociation -> {
				roleIdList.add(targetUserAssociation.getRole());

				targetUserAccountAssets.put(targetUserAccount.getLegalEntityKey(), targetUserAssociation.getAssets());

				List<ValidateSiteRequest> requests = targetUserAssociation.getAssets().stream().filter(asset -> !StringUtils.isEmpty(asset.getAssetId()) || !StringUtils.isEmpty(asset.getSitePath())).map(asset -> {
					if (!StringUtils.isEmpty(asset.getAssetId())) {
						return ValidateSiteRequest.builder().assetId(asset.getAssetId()).build();
					}

					HashMap<String, String> parsedSitePath = AssetUtil.parseAssetPath(asset.getSitePath());
					ValidateSiteRequest validateRequest = new ValidateSiteRequest();

					if (parsedSitePath.containsKey(AssetUtil.SITE)) {
						validateRequest.setSitecode(parsedSitePath.get(AssetUtil.SITE));
					}

					if (parsedSitePath.containsKey(AssetUtil.CITY)) {
						validateRequest.setCity(parsedSitePath.get(AssetUtil.CITY));
					}

					if (parsedSitePath.containsKey(AssetUtil.METRO)) {
						validateRequest.setMetro(parsedSitePath.get(AssetUtil.METRO));
					}

					if (parsedSitePath.containsKey(AssetUtil.COUNTRY)) {
						validateRequest.setCountry(parsedSitePath.get(AssetUtil.COUNTRY));
					}

					if (parsedSitePath.containsKey(AssetUtil.REGION)) {
						validateRequest.setRegion(parsedSitePath.get(AssetUtil.REGION));
					}

					return validateRequest;
				}).collect(Collectors.toList());

				AssetValidationRequest request = AssetValidationRequest.builder().accountId(targetUserAccount.getLegalEntityKey()).siteRequests(requests).build();
				targetUserAssetValidation.add(request);
			});

			targetUserAccountRoles.put(targetUserAccount.getLegalEntityKey(), roleIdList);
		});

		permissionsService.validateRoles(RoleValidationRequest.builder().roleAccountAssociation(targetUserAccountRoles).build());
		assetService.validateAssets(targetUserAssetValidation);

		targetUser = userDBService.saveUserAssignments(targetUserId, includeInternal, userAccountAssignmentRequest, targetUserAccountRoles, targetUserAccountAssets);
		jmsUserService.sendMessage(new MaintainUserMessage(targetUser.getId(), UserRequestType.UPDATED));
		sendEmail(targetUser, ContextUtility.getUserEmail(),  EmailType.NEW_ACCOUNT_ASSIGNED);
		return targetUser;
	}

	public UserAccountApprovalResponse updateUserAccountApproval(UserAccountApprovalRequest userAccountApproval) {
		String encryptedEmail = encryptionService.encryptEmail(ContextUtility.getUserEmail());

		User user = userDBService.findByEmail(encryptedEmail);
		if (Objects.isNull(user)) {
			throw new CommonException(UserErrorCode.USER_NOTFOUND);
		}

		Map<UUID, ApprovalStatus> userAccountStatus = new HashMap<UUID, ApprovalStatus>();
		List<UserAccount> userAccounts = userAccountDBService.findByIdIn(userAccountApproval.getUserAccounts().keySet().stream().collect(Collectors.toList()));
		userAccountApproval.getUserAccounts().keySet().forEach(userAccountId -> {
			Optional<UserAccount> loggedUserAccount = userAccounts.stream().filter(userAccount -> userAccount.getId().equals(userAccountId) && userAccount.getUserId().equals(user.getId())).findFirst();
			if (loggedUserAccount.isEmpty()) {
				throw new CommonException(UserErrorCode.USER_ACCOUNT_NOTFOUND);
			}

			userAccountStatus.put(userAccountId, userAccountApproval.getUserAccounts().get(userAccountId));
		});

		sendEmail(user, user.getCreatedBy(), EmailType.NEW_ACCOUNT_REJECTED);
		return UserAccountApprovalResponse.builder().userAccounts(userAccountDBService.saveAccountApprovals(userAccountStatus).stream().map(UserAccount::getId).collect(Collectors.toList())).build();
	}

	public UserAccountStatusResponse updateUserAccountStatus(UUID targetUserId, UserAccountStatusRequest userAccountApproval) {
		List<CommonException> exceptions = new ArrayList<CommonException>();
		userAccountApproval.getUserAccounts().forEach((legalEntityKey, userAccountStatus) -> {
			if (userAccountStatus == UserAccountStatus.AUTO_SUSPENDED) {
				exceptions.add(new CommonException(UserErrorCode.STATUS_NOT_ALLOWED));
			}
		});

		if (!exceptions.isEmpty()) {
			throw CommonException.fromList(exceptions);
		}

		User targetUser = userDBService.updateUserAccountStatus(targetUserId, userAccountApproval.getUserAccounts());

		jmsUserService.sendMessage(new MaintainUserMessage(targetUser.getId(), UserRequestType.UPDATED));
		return UserAccountStatusResponse.builder().user(targetUser).build();
	}

	public UserAccountResponse getUserAccounts() {
		String encryptedEmail = encryptionService.encryptEmail(ContextUtility.getUserEmail());

		List<UserAccount> userAccounts = userAccountDBService.findByUserEmailAndApprovalStatus(encryptedEmail, ApprovalStatus.APPROVED);

		boolean hasAny = (userAccounts.stream().filter(UserAccount::getAnyAccount).count() > 0);
		String superUser = superUserDBService.findByEmail(encryptedEmail);

		if (Objects.isNull(userAccounts) || userAccounts.isEmpty()) {
			if (Objects.isNull(superUser)) {
				throw new CommonException(UserErrorCode.USER_NOTFOUND);
			}

			return UserAccountResponse.builder().superUser(true).anyAccount(userAccounts.stream().anyMatch(UserAccount::getAnyAccount)).build();
		}

		return UserAccountResponse.builder().superUser(!StringUtils.isEmpty(superUser)).anyAccount(hasAny).userAccounts(userAccounts.stream().collect(Collectors.toMap(UserAccount::getLegalEntityKey, UserAccount::getDefaultAccount))).build();
	}

	public void manageDefaultAccount() {
		String encryptedEmail = encryptionService.encryptEmail(ContextUtility.getUserEmail());

		List<UserAccount> userAccounts = userAccountDBService.findByUserEmailAndApprovalStatus(encryptedEmail, ApprovalStatus.APPROVED);
		if (Objects.isNull(userAccounts) || userAccounts.isEmpty()) {
			throw new CommonException(UserErrorCode.USER_ACCOUNT_NOTFOUND);
		}

		userAccountDBService.manageDefaultAccount(userAccounts);
	}

	public List<UserAccount> getUserAccountAssociations() {
		String encryptedEmail = encryptionService.encryptEmail(ContextUtility.getUserEmail());
		return userAccountDBService.findByUserEmailAndApprovalStatus(encryptedEmail, ApprovalStatus.INVITE_SENT);
	}

	public Integer getActiveUserCount(String legalEntityKey) {
		return userAccountDBService.getActiveUserCount(legalEntityKey);
	}

	public Page<UserResponse> getUsersWithAccount(UserAccountsRequest userAccountsRequest, Pageable pageable,
			String filterFirstName, String filterLastName, String filterEmail, String filterPhone, String filterStatus) {
		UserEntityPredicatesBuilder userEntityPredicatesBuilder = new UserEntityPredicatesBuilder();

		userEntityPredicatesBuilder.with("id", "in", userAccountsRequest.getUserIds());

		if (!Objects.isNull(filterFirstName)) {
			userEntityPredicatesBuilder.with("firstName", ":", filterFirstName);
		}
		if (!Objects.isNull(filterFirstName)) {
			userEntityPredicatesBuilder.with("lastName", ":", filterLastName);
		}
		if (!Objects.isNull(filterFirstName)) {
			userEntityPredicatesBuilder.with("email", ":", filterEmail);
		}
		if (!Objects.isNull(filterFirstName)) {
			userEntityPredicatesBuilder.with("phone", ":", filterPhone);
		}
		if (!Objects.isNull(filterFirstName)) {
			userEntityPredicatesBuilder.with("status", ":", filterStatus);
		}

		Page<UserEntity> users = dynamicUserRepository.findAll(userEntityPredicatesBuilder.build(), pageable);
		List<String> legalEntityKeys = users.getContent().stream().flatMap(user -> user.getUserAccounts().stream().map(UserAccountEntity::getLegalEntityKey)).collect(Collectors.toList());

		List<GetAccountsResponse> accounts = accountService.getAccounts(legalEntityKeys);

		return new PageImpl<UserResponse>(users.getContent().stream()
				.map(user -> userMapper.mapToUserResponse(user, user.getUserAccounts().stream()
						.map(userAccount -> {
							Optional<GetAccountsResponse> userAcc = accounts.stream().filter(account -> account.getLegalEntityKey().equalsIgnoreCase(userAccount.getLegalEntityKey())).findFirst();
							return userAccountMapper.mapToUserAccountsResponse(
									userAccount,
									userAcc.isPresent() ? userAcc.get() : null);
						}).collect(Collectors.toList())))
				.collect(Collectors.toList()),
				pageable, users.getTotalElements());
	}
	
	private void sendEmail(User targetUser, String userEmail, EmailType emailType) {
		Map<String, String> sendTo = new HashMap<>();
		sendTo.put(userEmail, targetUser.getFirstName()+" "+ targetUser.getLastName());
		sendEmailMessage.setSendTo(sendTo);
		sendEmailMessage.setEmailTemplateType(emailType);
		emailService.sendEmail(sendEmailMessage);
	}
}
