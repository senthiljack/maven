package com.digitalrealty.gapi.user.enums;

public enum UserStatus {
	CREATED,
	DRAFT,
	NOTACTIVE,
	ACTIVE
}
