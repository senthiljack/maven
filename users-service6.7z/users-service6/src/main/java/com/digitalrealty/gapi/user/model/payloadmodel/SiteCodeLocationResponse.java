package com.digitalrealty.gapi.user.model.payloadmodel;

public interface SiteCodeLocationResponse {
	String getAssetId();

	String getParentId();

	String getAssetName();

	String getType();

	String getRegion();

	String getCountry();

	String getMetro();

	String getCity();

	String getSitecode();
}
