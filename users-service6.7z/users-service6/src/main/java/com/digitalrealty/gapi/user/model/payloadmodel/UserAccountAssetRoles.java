package com.digitalrealty.gapi.user.model.payloadmodel;

import java.util.List;

import org.springframework.validation.annotation.Validated;

import com.digitalrealty.gapi.user.validation.AnyAccountMatch;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Validated
@AnyAccountMatch(anyAccountField = "anyAccount", legalEntityField = "legalEntityKey", associationField = "associations", message = "LegalEntityKey or AnyAccount is empty")
public class UserAccountAssetRoles {

	Boolean anyAccount;

	String legalEntityKey;

	List<RoleAssets> associations;

}