package com.digitalrealty.gapi.user.repository;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.digitalrealty.gapi.user.entity.SuperUserEntity;

@Repository
public interface SuperUserRepository extends CrudRepository<SuperUserEntity, UUID> {

	String findByEmail(String email);

}