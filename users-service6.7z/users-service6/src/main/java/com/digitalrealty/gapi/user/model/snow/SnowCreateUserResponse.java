package com.digitalrealty.gapi.user.model.snow;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SnowCreateUserResponse {

	private List<SnowResult> result;

}