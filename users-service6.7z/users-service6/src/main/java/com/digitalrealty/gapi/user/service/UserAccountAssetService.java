package com.digitalrealty.gapi.user.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.exception.UserErrorCode;
import com.digitalrealty.gapi.user.model.IUserAccountAsset;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.model.payloadmodel.AssetModel;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssetResponse;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserAccountAssetService {

	private final SuperUserDBService superUserDBService;

	private final UserAccountAssetDBService userAccountAssetDBService;

	private final UserAccountDBService userAccountDBService;

	private final EncryptionService encryptionService;

	public UserAccountAssetResponse getUserAssets() {
		String encryptedEmail = encryptionService.encryptEmail(ContextUtility.getUserEmail());

		List<UserAccount> userAccounts = userAccountDBService.findByUserEmailAndApprovalStatus(encryptedEmail, ApprovalStatus.APPROVED);

		boolean hasAny = (userAccounts.stream().filter(UserAccount::getAnyAccount).count() > 0);
		String superUser = superUserDBService.findByEmail(encryptedEmail);

		Optional<UserAccount> loggedAccount = userAccounts.stream().filter(userAcc -> userAcc.getLegalEntityKey().equals(ContextUtility.getLegalEntity())).findFirst();
		if (loggedAccount.isEmpty()) {
			if (StringUtils.isEmpty(superUser)) {
				throw new CommonException(UserErrorCode.USER_NOTFOUND);
			}

			return UserAccountAssetResponse.builder().superUser(true).anyAccount(hasAny).build();
		}

		List<IUserAccountAsset> userAccountAssets = userAccountAssetDBService.findIdsByUserAccountId(loggedAccount.get().getId());
		return UserAccountAssetResponse.builder().superUser(!StringUtils.isEmpty(superUser)).anyAccount(hasAny).userAccountAssets(userAccountAssets.stream().map(userAsset -> new AssetModel(userAsset.getAssetId(), userAsset.getSitePath())).collect(Collectors.toList())).build();
	}

}
