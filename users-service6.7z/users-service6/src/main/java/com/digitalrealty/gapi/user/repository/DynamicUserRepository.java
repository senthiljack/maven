package com.digitalrealty.gapi.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;
import org.springframework.data.querydsl.binding.QuerydslBindings;
import org.springframework.data.querydsl.binding.SingleValueBinding;

import com.digitalrealty.gapi.user.entity.QUserEntity;
import com.digitalrealty.gapi.user.entity.UserEntity;
import com.querydsl.core.types.dsl.StringExpression;
import com.querydsl.core.types.dsl.StringPath;

public interface DynamicUserRepository extends JpaRepository<UserEntity, String>, QuerydslPredicateExecutor<UserEntity>, QuerydslBinderCustomizer<QUserEntity> {

	@Override
	default void customize(QuerydslBindings bindings, QUserEntity root) {
		bindings.bind(String.class)
				.first((SingleValueBinding<StringPath, String>) StringExpression::containsIgnoreCase);
	}

}