package com.digitalrealty.gapi.user.mapper;

import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import com.digitalrealty.gapi.user.entity.UserAccountRoleEntity;
import com.digitalrealty.gapi.user.model.IUserAccountRole;
import com.digitalrealty.gapi.user.model.UserAccountRole;
import com.digitalrealty.gapi.user.repository.UserAccountRepository;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, builder = @Builder(disableBuilder = true), uses = { MappingUtil.class, UserAccountRepository.class })
public interface UserAccountRoleMapper {

	@Mapping(target = "userAccountRoleAssets", source = "userAccountRoleAssetsId", qualifiedByName = "getUserAccountRoleAssetById")
	UserAccountRoleEntity map(UserAccountRole userAccountRole);

	@Mapping(target = "userAccountRoleAssetsId", source = "userAccountRoleAssets.id")
	UserAccountRole map(UserAccountRoleEntity userAccountRoleEntity);

	UserAccountRole map(IUserAccountRole iUserAccountRole);
}
