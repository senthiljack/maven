package com.digitalrealty.gapi.user.model;

import java.util.UUID;

public interface IUserAccountRole extends BaseInterface {

	UUID getRoleId();

	UUID getUserAccountRoleAssetsId();
}
