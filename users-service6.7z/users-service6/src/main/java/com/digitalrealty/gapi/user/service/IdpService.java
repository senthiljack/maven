package com.digitalrealty.gapi.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.digitalrealty.gapi.common.auth.service.IdpAuthService;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.CommonExceptionUtil;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.user.enums.InternalStatus;
import com.digitalrealty.gapi.user.enums.UserStatus;
import com.digitalrealty.gapi.user.model.User;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class IdpService {

	public static final String UNAUTHORIZED = "401";

	private final UserDBService userDBService;

	private final IdpAuthService idpAuthService;

	private final IdpServiceRetryable idpServiceRetryable;

	public List<User> syncUsersToIdp(List<User> initiatedUsers) {
		log.trace("Synchronizing Users to Idp");
		List<User> syncedUsers = new ArrayList<User>();

		List<User> createList = initiatedUsers.stream().filter(user -> (user.getStatus() == UserStatus.CREATED)).collect(Collectors.toList());
		List<User> updateList = initiatedUsers.stream().filter(user -> (user.getStatus() == UserStatus.ACTIVE)).collect(Collectors.toList());
		List<User> deleteList = initiatedUsers.stream().filter(user -> (user.getStatus() == UserStatus.NOTACTIVE)).collect(Collectors.toList());

		List<CommonException> commonExceptions = new ArrayList<CommonException>();
		createList.forEach(user -> {
			try {
				try {
					idpServiceRetryable.createIdpUser(user);
				} catch (Exception exception) {
					if ((exception.getMessage() == null) || !exception.getMessage().contains(UNAUTHORIZED)) {
						throw new CommonException(ErrorCode.BAD_REQUEST);
					}
					idpAuthService.getAccessToken(true);
					idpServiceRetryable.createIdpUser(user);
				}

				user.setInternalStatus(InternalStatus.IDP_SYNCED);
				syncedUsers.add(user);
			} catch (Exception ex) {
				commonExceptions.add(CommonExceptionUtil.convertExceptionToCommonException(ex, null));
			}
		});

		updateList.forEach(user -> {
			try {
				try {
					idpServiceRetryable.updateIdpUser(user);
				} catch (Exception exception) {
					if ((exception.getMessage() == null) || !exception.getMessage().contains(UNAUTHORIZED)) {
						throw new CommonException(ErrorCode.BAD_REQUEST);
					}
					idpAuthService.getAccessToken(true);
					idpServiceRetryable.updateIdpUser(user);
				}

				user.setInternalStatus(InternalStatus.IDP_SYNCED);
				syncedUsers.add(user);
			} catch (Exception ex) {
				commonExceptions.add(CommonExceptionUtil.convertExceptionToCommonException(ex, null));
			}
		});

		deleteList.forEach(user -> {
			try {
				try {
					idpServiceRetryable.deleteIdpUser(user);
				} catch (Exception exception) {
					if ((exception.getMessage() == null) || !exception.getMessage().contains(UNAUTHORIZED)) {
						throw new CommonException(ErrorCode.BAD_REQUEST);
					}
					idpAuthService.getAccessToken(true);
					idpServiceRetryable.deleteIdpUser(user);
				}

				user.setInternalStatus(InternalStatus.IDP_SYNCED);
				syncedUsers.add(user);
			} catch (Exception ex) {
				commonExceptions.add(CommonExceptionUtil.convertExceptionToCommonException(ex, null));
			}
		});

		List<User> savedUsers = userDBService.saveUsers(syncedUsers);

		if (!commonExceptions.isEmpty()) {
			throw CommonException.fromList(commonExceptions);
		}

		log.trace("Synchronized Users to Idp");
		return savedUsers;
	}

}
