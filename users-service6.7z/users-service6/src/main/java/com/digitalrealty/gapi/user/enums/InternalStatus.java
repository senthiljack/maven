package com.digitalrealty.gapi.user.enums;

public enum InternalStatus {
	NEED_SYNC,
	IDP_SYNCED,
	SNOW_SYNCED,
	EMAIL_SYNCED,
	EMAIL_SYNC_NOT_NEEDED,
	NEED_ASSIGNMENT_SYNC,
	SYNCED
}
