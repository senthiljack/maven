package com.digitalrealty.gapi.user.model.snow;

import org.springframework.validation.annotation.Validated;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
public class SNowUpdateUser {

	private String u_last_contact_to_update;

	private String u_access_area_visitor;

	private String u_access_area_owner;

	private String u_operations_contact;

}
