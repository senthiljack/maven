package com.digitalrealty.gapi.user.model.payloadmodel;

import java.util.Map;

import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import com.digitalrealty.gapi.user.enums.UserAccountStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Validated
public class UserAccountStatusRequest {

	@NotEmpty
	Map<String, UserAccountStatus> userAccounts;

}
