package com.digitalrealty.gapi.user.mapper;

import java.util.UUID;

import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssociations;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, builder = @Builder(disableBuilder = true))
public interface ActionMapper {

	ActionValidationResponse mapUserToActionValidationResponse(Boolean superUser, UUID userId, UserAccountAssociations associations);

}
