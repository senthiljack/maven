package com.digitalrealty.gapi.user.entity;

import java.time.Instant;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import com.digitalrealty.gapi.user.enums.InternalStatus;
import com.digitalrealty.gapi.user.enums.TermStatus;
import com.digitalrealty.gapi.user.enums.UserStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Audited
@Table(name = "users")
public class UserEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	private String firstName;

	private String lastName;

	private String email;

	private String phone;

	@Enumerated(EnumType.STRING)
	private UserStatus status;

	@Enumerated(EnumType.STRING)
	private InternalStatus internalStatus;

	@Enumerated(EnumType.STRING)
	private TermStatus termsAndConditionsStatus;

	private Instant termsAndConditionsDate;

	private String termsAndConditionsVersion;

	private Instant statusChangeDate;

	@OneToMany(mappedBy = "user")
	private Set<UserAccountEntity> userAccounts;
}
