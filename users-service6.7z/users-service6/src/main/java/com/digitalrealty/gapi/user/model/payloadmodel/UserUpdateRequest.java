package com.digitalrealty.gapi.user.model.payloadmodel;

import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

import org.springframework.validation.annotation.Validated;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Validated
public class UserUpdateRequest {

	@Size(max = 50)
	@Schema(example = "John")
	private String firstName;

	@Size(max = 50)
	@Schema(example = "Doe")
	private String lastName;

	@Size(max = 100)
	@Email
	@Schema(example = "jdoe@digitalrealy.com")
	private String email;

	@Size(max = 40)
	@Schema(example = "999-999-9999")
	private String phone;
}
