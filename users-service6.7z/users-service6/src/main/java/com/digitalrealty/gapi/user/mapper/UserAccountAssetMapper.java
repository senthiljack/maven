package com.digitalrealty.gapi.user.mapper;

import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import com.digitalrealty.gapi.user.entity.UserAccountAssetEntity;
import com.digitalrealty.gapi.user.model.IUserAccountAsset;
import com.digitalrealty.gapi.user.model.UserAccountAsset;
import com.digitalrealty.gapi.user.repository.UserAccountRepository;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, builder = @Builder(disableBuilder = true), uses = { MappingUtil.class, UserAccountRepository.class })
public interface UserAccountAssetMapper {

	@Mapping(target = "userAccountRoleAssets", source = "userAccountRoleAssetsId", qualifiedByName = "getUserAccountRoleAssetById")
	UserAccountAssetEntity map(UserAccountAsset userAccountAsset);

	@Mapping(target = "userAccountRoleAssetsId", source = "userAccountRoleAssets.id")
	UserAccountAsset map(UserAccountAssetEntity userAccountAssetEntity);

	UserAccountAsset map(IUserAccountAsset iUserAccountAsset);
}
