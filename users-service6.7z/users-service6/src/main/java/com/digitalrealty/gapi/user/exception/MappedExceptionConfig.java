package com.digitalrealty.gapi.user.exception;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.digitalrealty.gapi.common.exceptions.CommonExceptionsConfiguration;

@Configuration
public class MappedExceptionConfig {

	@Autowired
	CommonExceptionsConfiguration configuration;

	@PostConstruct
	public void init() {
		configuration.mapErrorCode("NotBlank.CreateUserRequest.firstName", UserErrorCode.MISSING_FIRST_NAME);
		configuration.mapErrorCode("Size.CreateUserRequest.firstName", UserErrorCode.LONG_FIRST_NAME);

		configuration.mapErrorCode("NotBlank.CreateUserRequest.lastName", UserErrorCode.MISSING_LAST_NAME);
		configuration.mapErrorCode("Size.CreateUserRequest.lastName", UserErrorCode.LONG_LAST_NAME);

		configuration.mapErrorCode("NotBlank.CreateUserRequest.email", UserErrorCode.MISSING_EMAIL);
		configuration.mapErrorCode("Size.CreateUserRequest.email", UserErrorCode.LONG_EMAIL);
		configuration.mapErrorCode("Email.CreateUserRequest.email", UserErrorCode.VALID_EMAIL);

		configuration.mapErrorCode("Size.CreateUserRequest.phone", UserErrorCode.LONG_PHONE);

		configuration.mapErrorCode("AnyAccountMatch.userAccounts", UserErrorCode.ANYACCOUNT_OR_LEGAL);
	}
}
