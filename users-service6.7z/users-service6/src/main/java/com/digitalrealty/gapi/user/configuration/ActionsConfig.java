package com.digitalrealty.gapi.user.configuration;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
import lombok.NoArgsConstructor;

@Configuration
@NoArgsConstructor
@Data
@ConfigurationProperties(prefix = "actions")
public class ActionsConfig {

	private List<String> createUser;
	private List<String> updateUser;
	private List<String> getUserProfile;
	private List<String> getUsersInAccount;
	private List<String> manageAssignments;
	private List<String> manageAssignmentsInternal;
	private List<String> updateUserStatus;
	private List<String> getUsersWithAccount;
	private List<String> getDeletedUserAccountForGU;

}
