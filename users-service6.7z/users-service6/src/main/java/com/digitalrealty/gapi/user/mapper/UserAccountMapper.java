package com.digitalrealty.gapi.user.mapper;

import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import com.digitalrealty.gapi.user.entity.UserAccountEntity;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.model.payloadmodel.GetAccountsResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountsResponse;
import com.digitalrealty.gapi.user.repository.UserRepository;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, builder = @Builder(disableBuilder = true), uses = { MappingUtil.class, UserAccountAssetMapper.class, UserAccountRoleMapper.class, UserRepository.class })
public interface UserAccountMapper {

	@Mapping(target = "user", source = "userId", qualifiedByName = "getUserByUserId")
	UserAccountEntity map(UserAccount userAccount);

	@Mapping(target = "userId", source = "user.id")
	UserAccount map(UserAccountEntity userAccountEntity);

	@Mapping(target = "userAccountId", source = "userAccount.id")
	@Mapping(target = "legalEntityKey", source = "userAccount.legalEntityKey")
	@Mapping(target = "status", source = "userAccount.status")
	@Mapping(target = "approvalStatus", source = "userAccount.approvalStatus")
	@Mapping(target = "defaultAccount", source = "userAccount.defaultAccount")
	@Mapping(target = "anyAccount", source = "userAccount.anyAccount")
	@Mapping(target = "statusChangedDate", source = "userAccount.statusChangedDate")
	@Mapping(target = "account", source = "account")
	UserAccountsResponse mapToUserAccountsResponse(UserAccountEntity userAccount, GetAccountsResponse account);

	@Mapping(target = "userAccountId", source = "userAccount.id")
	@Mapping(target = "legalEntityKey", source = "userAccount.legalEntityKey")
	@Mapping(target = "status", source = "userAccount.status")
	@Mapping(target = "approvalStatus", source = "userAccount.approvalStatus")
	@Mapping(target = "defaultAccount", source = "userAccount.defaultAccount")
	@Mapping(target = "anyAccount", source = "userAccount.anyAccount")
	@Mapping(target = "statusChangedDate", source = "userAccount.statusChangedDate")
	UserAccountsResponse mapToUserAccountsResponse(UserAccountEntity userAccount);
}