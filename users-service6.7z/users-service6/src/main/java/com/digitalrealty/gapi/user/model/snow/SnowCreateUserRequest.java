package com.digitalrealty.gapi.user.model.snow;

import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SnowCreateUserRequest {

	private UUID id;

	@JsonProperty("firstname")
	private String firstName;

	@JsonProperty("lastname")
	private String lastName;

	private String email;

	private String phone;

	private List<String> roles;

	@JsonProperty("op")
	private String operations;
}
