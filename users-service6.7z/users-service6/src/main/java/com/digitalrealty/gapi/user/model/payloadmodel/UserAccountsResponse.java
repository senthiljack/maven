package com.digitalrealty.gapi.user.model.payloadmodel;

import java.time.Instant;
import java.util.UUID;

import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserAccountsResponse {
	public UUID userAccountId;

	public String legalEntityKey;

	public UserAccountStatus status;

	public ApprovalStatus approvalStatus;

	public Boolean defaultAccount;

	public Boolean anyAccount;

	public Instant statusChangedDate;

	public GetAccountsResponse account;
}
