package com.digitalrealty.gapi.user.service;

import com.digitalrealty.gapi.common.context.ContextHeaders;
import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.common.exceptions.ErrorCode;
import com.digitalrealty.gapi.common.jwt.configuration.JwtConfig;
import com.digitalrealty.gapi.common.jwt.security.RedisCacheService;
import com.digitalrealty.gapi.messaging.email.SendEmailMessage;
import com.digitalrealty.gapi.user.configuration.UserConfig;
import com.digitalrealty.gapi.user.enums.InternalStatus;
import com.digitalrealty.gapi.user.enums.UserStatus;
import com.digitalrealty.gapi.user.model.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@Slf4j
@RequiredArgsConstructor
public class EmailService {

	private final UserDBService userDBService;

	private final WebClient webClient;

	private final UserConfig userConfig;

	private final RedisCacheService redisCacheService;

	private final JwtConfig jwtConfig;

	@Retryable(value = CommonException.class, maxAttempts = 3)
	public Integer notifyUser(User user) {
		// TODO implement webclient post
		return 1;
	}

	public List<User> notifySyncedUsers(List<User> initiatedUsers) {
		log.trace("Notifying syncronized Users via email");
		List<User> syncUsers = new ArrayList<User>();

		List<CommonException> commonExceptions = new ArrayList<CommonException>();
		initiatedUsers.forEach(user -> {
			Integer emailUserId = notifyUser(user);

			if (Objects.isNull(emailUserId) || emailUserId == 0) {
				commonExceptions.add(new CommonException(ErrorCode.BAD_REQUEST));
			}

			user.setInternalStatus(InternalStatus.SYNCED);
			user.setStatus(UserStatus.DRAFT);
			syncUsers.add(user);
		});

		List<User> savedUsers = userDBService.saveUsers(syncUsers);

		if (!commonExceptions.isEmpty()) {
			throw CommonException.fromList(commonExceptions);
		}

		log.trace("Notified Users via email");
		return savedUsers;
	}
	@Retryable(value = CommonException.class, maxAttempts = 3)
	public void sendEmail(SendEmailMessage sendEmailMessage) {
		webClient.post()
				.uri(userConfig.getEmailServiceURL() + "/emails/send-emails")
				.header("Authorization", "Bearer " + redisCacheService.getObjectFromCache(StringUtils.join(jwtConfig.getKeyPrefix(), ContextUtility.getUserEmail())))
				.headers(ContextHeaders.getHeaderConsumer())
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(sendEmailMessage), SendEmailMessage.class)
				.retrieve()
				.onStatus(HttpStatus::is5xxServerError, clientResponse -> Mono.error(new CommonException(ErrorCode.DOWNSTREAM_SERVICE_ERROR )))
				.toBodilessEntity()
				.block();
	}
}
