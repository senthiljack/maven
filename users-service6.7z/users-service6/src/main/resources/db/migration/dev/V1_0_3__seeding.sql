INSERT INTO user_gapi.super_user VALUES ('phantom.aao.dlr@gmail.com');


INSERT INTO user_gapi.super_user VALUES ('globalportal@outlook.com');
