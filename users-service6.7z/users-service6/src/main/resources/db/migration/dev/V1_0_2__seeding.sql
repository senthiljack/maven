INSERT INTO user_gapi.super_user VALUES ('admin@digitalrealty.com');


INSERT INTO user_gapi.users (id, version, email, first_name, last_name, phone, position, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('4c10a6a0-ce99-4020-a790-1bc728efe569', 0, 'gapi-dlr-super-user@digitalrealty.com', 'Gauri', 'Shinde', '2345678123', 'Position', 'CREATED', '2022-03-24 03:03:03', 'ACCEPTED', '2022-03-24 03:03:03', 'ejb55@gmailiz.com', '2022-03-24 03:03:03', 'unknown', 'johnwea1@onlinecmail.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.users(id, version, email, first_name, last_name, phone, position, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('a113a69a-ed40-4505-a5ab-19ba73478374',  0, 'gapi-dlr-support-user@digitalrealty.com', 'Terrence', 'Corstan', '2345678123', 'Position', 'DRAFT', '2022-03-24 03:03:03', 'ACCEPTED', '2022-03-24 03:03:03', 'gapingredgroovie@sungkian.com', '2022-03-24 03:03:03', 'unknown', 'kmahendra@gecici.ml', '2022-04-25 03:03:03' );

INSERT INTO user_gapi.users(id, version, email, first_name, last_name, phone, position, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('fc2c22b8-d644-484c-90b7-dcdf4c73fac2',  0, 'gapi-dlr-user@digitalrealty.com', 'Janella', 'Eustice', '2345678123', 'Position', 'NOTACTIVE', '2022-03-24 03:03:03', 'ACCEPTED', '2022-03-24 03:03:03', 'shevadiman@networkofemail.com', '2022-03-24 03:03:03', 'unknown','johnwea1@onlinecmail.com', '2022-04-25 03:03:03');



INSERT INTO user_gapi.users (id, version, email, first_name, last_name, phone, position, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('f07f4d57-f9f4-46c4-8679-51a19ab24c37', 0, 'gapi-super-admin@digitalrealty.com', 'Anabel', 'Schmitt', '2345678123', 'Position', 'CREATED', '2022-03-24 03:03:03', 'ACCEPTED', '2022-03-24 03:03:03', 'ejb55@gmailiz.com', '2022-03-24 03:03:03', 'unknown', 'johnwea1@onlinecmail.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.users(id, version, email, first_name, last_name, phone, position, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('8d6b2a51-24d3-43ce-9d39-b65768ebc8ff',  0, 'gapi-account-admin@digitalrealty.com', 'Aurelio', 'Shields', '2345678123', 'Position', 'DRAFT', '2022-03-24 03:03:03', 'ALERTED', '2022-03-24 03:03:03', 'gapingredgroovie@sungkian.com', '2022-03-24 03:03:03', 'unknown', 'kmahendra@gecici.ml', '2022-04-25 03:03:03' );

INSERT INTO user_gapi.users(id, version, email, first_name, last_name, phone, position, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('1a36ea15-e433-4ce9-a63d-4175cac108c8',  0, 'gapi-site-admin@digitalrealty.com', 'Meredith', 'Jast', '2345678123', 'Position', 'NOTACTIVE', '2022-03-24 03:03:03', 'REJECTED', '2022-03-24 03:03:03', 'shevadiman@networkofemail.com', '2022-03-24 03:03:03', 'unknown','johnwea1@onlinecmail.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.users(id, version, email, first_name, last_name, phone, position, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('3a9576d4-f167-461c-94d4-09ef18d1d113',  0, 'gapi-portal-user@digitalrealty.com', 'Kali', 'Waelchi', '2345678123', 'Position', 'CREATED',  '2022-03-24 03:03:03', 'ACCEPTED', '2022-03-24 03:03:03', 'rainnermag@bestiengine.com', '2022-03-24 03:03:03', 'unknown','74oni9qcbghzu@mercantravellers.com', '2022-04-25 03:03:03');
INSERT INTO user_gapi.users(id, version, email, first_name, last_name, phone, position, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('659fcf98-2d82-4236-916c-c6cd0e7ce329',  0, 'gapi-test-user1@digitalrealty.com', 'Fabiola', 'Rolfson', '2345678123', 'Position', 'CREATED',  '2022-03-24 03:03:03', 'ALERTED', '2022-03-24 03:03:03', 'dixonpe@sewce.com',  '2022-03-24 03:03:03', 'unknown','shoeski@dmxs8.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.users(id, version, email, first_name, last_name, phone, position, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('e672ea75-23a1-40ca-b019-e888c9a1f89c',  0, 'gapi-test-user2@digitalrealty.com', 'Maximillia', 'Feest', '2345678123', 'Position', 'ACTIVE', '2022-03-24 03:03:03', 'ACCEPTED', '2022-03-24 03:03:03', 'stas8914erema@abreutravel.com', '2022-03-24 03:03:03', 'unknown', 'anagrammatic@tchoeo.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.users(id, version, email, first_name, last_name, phone, position, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date , terms_and_conditions_version, last_modified_by, last_modified_date) 
  VALUES('eea9b5b5-fc0f-41b7-bccf-96706430eff4',  0, 'gapi-test-user3@digitalrealty.com', 'Christy', 'Lehner', '2345678123', 'Position', 'DRAFT',  '2022-03-24 03:03:03', 'ALERTED', '2022-03-24 03:03:03', 'ivory123456@ibnlolpla.com', '2022-03-24 03:03:03', 'unknown', 'kevin0420@eluvit.com', '2022-04-25 03:03:03');




INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date )
  VALUES('e8404447-1f92-480c-b7d0-58ed45f1751e',  0, 'roosterj@nkgursr.com', '2022-03-28 03:03:03', '0012E00002dzucpQAA', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', '4c10a6a0-ce99-4020-a790-1bc728efe569', 'aeajyz@aenikaufa.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('f953e97c-3f6d-479b-ba26-67d99ee3bbd4',  0, 'elnenenatoloka@onlinecmail.com', '2022-03-28 03:03:03', '0012E00002dzucrQAA', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', '4c10a6a0-ce99-4020-a790-1bc728efe569', 'gardenangel3@hotmail.red', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('53788f0e-67ef-4039-9d62-ef5bf722f2bf',  0, 'k3nt@crtapev.com', '2022-03-28 03:03:03', '0012E00002dzuJWQAY', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', 'a113a69a-ed40-4505-a5ab-19ba73478374', 'mikhailkadykov@isueir.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('87b7a694-c905-48fa-8886-5c6f98b6c15b',  0, '2hpzz7@bedulsenpai.net', '2022-03-28 03:03:03', '0012E00002dzucpQAA', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', 'a113a69a-ed40-4505-a5ab-19ba73478374', 'kam3358@hstuie.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('045e2173-5773-4a2f-899f-2f1f72dba7fa',  0, 'glousiea@hotmail.red', '2022-03-28 03:03:03', '0012E00002dzucrQAA', 'REJECTED', 1, 1, 'MANUALLY_SUSPENDED', '2022-03-28 03:03:03', 'fc2c22b8-d644-484c-90b7-dcdf4c73fac2', 'drury1@bestiengine.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('07535e94-e612-474f-a8b8-927b4896f6e2',  0, 'allatumanova@specialkien.website', '2022-03-28 03:03:03', '0012E00002dzuJWQAY', 'REJECTED', 1, 1,'MANUALLY_SUSPENDED', '2022-03-28 03:03:03', 'fc2c22b8-d644-484c-90b7-dcdf4c73fac2', 'rayclancy@onlinecmail.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('11972e86-6b21-4804-8f24-d8dc7d39ff7a',  0, 'emmareeves51@devih.site', '2022-03-28 03:03:03', '0012E00002dzuJWQAY', 'ALERTED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', '4c10a6a0-ce99-4020-a790-1bc728efe569', 'bstextile@eluvit.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('970d0adf-9837-433b-9a75-8eebf4b51d25',  0, 'kamshiloval@budgermile.rest', '2022-03-28 03:03:03', '0012E00002dzucpQAA', 'ALERTED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', 'fc2c22b8-d644-484c-90b7-dcdf4c73fac2', 'ddalsasso4014@hieu.in', '2022-04-25 03:03:03');




INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date )
  VALUES('844104ab-3d87-41d7-b537-a68f0c3dd8a4',  0, 'roosterj@nkgursr.com', '2022-03-28 03:03:03', '0012E00002dzucpQAA', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', 'f07f4d57-f9f4-46c4-8679-51a19ab24c37', 'aeajyz@aenikaufa.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('ab47cf00-066f-4c5b-9eed-43a6a23f62f0',  0, 'elnenenatoloka@onlinecmail.com', '2022-03-28 03:03:03', '0012E00002dzucrQAA', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', 'f07f4d57-f9f4-46c4-8679-51a19ab24c37', 'gardenangel3@hotmail.red', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('6f79068d-955e-43bb-89ed-b3998cfc63ac',  0, 'k3nt@crtapev.com', '2022-03-28 03:03:03', '0012E00002dzuJWQAY', 'ALERTED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', '8d6b2a51-24d3-43ce-9d39-b65768ebc8ff', 'mikhailkadykov@isueir.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('bdba51bf-bc7f-47fd-89a9-05baac3621f3',  0, '2hpzz7@bedulsenpai.net', '2022-03-28 03:03:03', '0012E00002dzucpQAA', 'ALERTED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', '8d6b2a51-24d3-43ce-9d39-b65768ebc8ff', 'kam3358@hstuie.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('9a16aa02-c77f-4817-a7b7-9b0f154e3042',  0, 'glousiea@hotmail.red', '2022-03-28 03:03:03', '0012E00002dzucrQAA', 'REJECTED', 1, 1, 'MANUALLY_SUSPENDED', '2022-03-28 03:03:03', '1a36ea15-e433-4ce9-a63d-4175cac108c8', 'drury1@bestiengine.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('76902450-b163-43a8-9abe-f0b4a60d72d3',  0, 'allatumanova@specialkien.website', '2022-03-28 03:03:03', '0012E00002dzuJWQAY', 'REJECTED', 1, 1,'MANUALLY_SUSPENDED', '2022-03-28 03:03:03', '1a36ea15-e433-4ce9-a63d-4175cac108c8', 'rayclancy@onlinecmail.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('9ad63e30-0527-4f2a-9873-714f54d869bf',  0, 'emmareeves51@devih.site', '2022-03-28 03:03:03', '0012E00002dzucpQAA', 'ALERTED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', '3a9576d4-f167-461c-94d4-09ef18d1d113', 'bstextile@eluvit.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('e0d5267e-6519-450e-aacd-ef53c996f21d',  0, 'kamshiloval@budgermile.rest', '2022-03-28 03:03:03', '0012E00002dzucrQAA', 'ALERTED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', '3a9576d4-f167-461c-94d4-09ef18d1d113', 'ddalsasso4014@hieu.in', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('19cb816a-7390-4c3e-b095-769926b37bd9',  0, 'rmm1182sims3@ulummky.com', '2022-03-28 03:03:03', '0012E00002dzuJWQAY', 'APPROVED', 1, 1 ,'ACTIVE', '2022-03-28 03:03:03', '659fcf98-2d82-4236-916c-c6cd0e7ce329', 'ththregeger@24hinbox.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('9d9fb4cc-ef50-4c57-b10e-c4eb8188b68d',  0, 'mocstb46@sungkian.com', '2022-03-28 03:03:03', '0012E00002dzucpQAA', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', '659fcf98-2d82-4236-916c-c6cd0e7ce329', 'malishkatanya22@bestiengine.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('4217e902-7b69-419e-813c-07a54c1fd71b',  0, '7enn@cuendita.com', '2022-03-28 03:03:03', '0012E00002dzucrQAA', 'ALERTED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', 'e672ea75-23a1-40ca-b019-e888c9a1f89c', 'jrosano@pickuplanet.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('58f326b3-db91-4527-bf0a-0e1a7bedfae4',  0, 'elcarin@lhtstci.com', '2022-03-28 03:03:03', '0012E00002dzuJWQAY', 'ALERTED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', 'e672ea75-23a1-40ca-b019-e888c9a1f89c', 'hoodasuresh63@neaeo.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('552ec6b1-bd1c-4549-8eec-d557b09493ff',  0, 'rbyers21@hotmail.red', '2022-03-28 03:03:03', '0012E00002dzucpQAA', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', 'eea9b5b5-fc0f-41b7-bccf-96706430eff4', 'zayaznastya@crashkiller.ovh', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date)
  VALUES('2977f88c-7dc9-4233-b339-dd0afac32ece',  0, 'nibpar@aihtnb.com', '2022-03-28 03:03:03', '0012E00002dzucrQAA', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', 'eea9b5b5-fc0f-41b7-bccf-96706430eff4', 'amkarkirill@gawe.works', '2022-04-25 03:03:03');



INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('7a15a3ce-1595-4fc8-8417-22c455826e5c', 1, 'mehrfragen@zdbgjajg.shop', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', 'e8404447-1f92-480c-b7d0-58ed45f1751e', 'martinn19@mymailcr.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('c2ac4762-ea04-4643-a159-53b68366e5fb',  0, 'hwxblu2g@mercantravellers.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', 'f953e97c-3f6d-479b-ba26-67d99ee3bbd4', 'digpig@sgisfg.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('02f6fec6-7237-44a2-9538-936e87086649',  0,  'fedorovp@aeissy.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '53788f0e-67ef-4039-9d62-ef5bf722f2bf', 'appraisals@rendrone.online', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('575f4481-6635-482d-b1fd-c6f3a7222e64',  0,  'vermarisha@fabtours.live', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '87b7a694-c905-48fa-8886-5c6f98b6c15b', 'willianlycan@termuxtech.tk', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('3129e64b-ee11-4d8b-97b5-fc6f4a4a6eb4',  0,  'googoo1@ulummky.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '045e2173-5773-4a2f-899f-2f1f72dba7fa', 'chelseaboy@gasssmail.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('1bd6cd06-7876-4668-a7fc-209f80bb8875',  0,  'nerthan@aenikaufa.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '07535e94-e612-474f-a8b8-927b4896f6e2', '9milxkn5@tchoeo.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('5a5e76d5-412b-446c-8815-057e6c64b502',  0,  'lilweat@gasss.us', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '11972e86-6b21-4804-8f24-d8dc7d39ff7a', 'avalon642@lompikachi.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('d533804a-14d1-4123-a188-ea1bf6c0cc8d',  0,  'guivignoli@euneeedn.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '970d0adf-9837-433b-9a75-8eebf4b51d25', 'poppu51@shubowtv.com', '2022-04-25 03:03:03');



INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('1bdc0c3e-afb5-4f0b-b612-26dea1db3dfc', 1, 'mehrfragen@zdbgjajg.shop', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '844104ab-3d87-41d7-b537-a68f0c3dd8a4', 'martinn19@mymailcr.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('3acc52bc-ee62-4abb-aea9-d90edc904a9f',  0, 'hwxblu2g@mercantravellers.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', 'ab47cf00-066f-4c5b-9eed-43a6a23f62f0', 'digpig@sgisfg.com', '2022-04-25 03:03:03');



INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('c6d2cefa-d739-449f-aa08-257ed4e73c7e',  0,  'fedorovp@aeissy.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '6f79068d-955e-43bb-89ed-b3998cfc63ac', 'appraisals@rendrone.online', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('16dcfda3-457e-4071-b77e-ecfff0835ca2',  0,  'vermarisha@fabtours.live', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', 'bdba51bf-bc7f-47fd-89a9-05baac3621f3', 'willianlycan@termuxtech.tk', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('c1f56014-816d-4e8d-82d3-b7d3ab23788e',  0,  'googoo1@ulummky.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '9a16aa02-c77f-4817-a7b7-9b0f154e3042', 'chelseaboy@gasssmail.com', '2022-04-25 03:03:03');



INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('e46d8771-41a3-4461-a696-b8be1f04651f',  0,  'nerthan@aenikaufa.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '76902450-b163-43a8-9abe-f0b4a60d72d3', '9milxkn5@tchoeo.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('6d08a24e-eb6d-4635-8732-aa30c1b25814',  0,  'lilweat@gasss.us', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '9ad63e30-0527-4f2a-9873-714f54d869bf', 'avalon642@lompikachi.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('62c58540-7607-43e8-9ca7-1e9d8be1daef',  0,  'guivignoli@euneeedn.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', 'e0d5267e-6519-450e-aacd-ef53c996f21d', 'poppu51@shubowtv.com', '2022-04-25 03:03:03');



INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('2864658e-55e3-4793-a108-c6c45c49e16d',  0,  'onhjxskv@lamiproi.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '19cb816a-7390-4c3e-b095-769926b37bd9', 'tomasroma@posthectomie.info', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('9a1186eb-2913-4b10-8de5-c81cc04fa438',  0,  'tpstamer@osmye.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '9d9fb4cc-ef50-4c57-b10e-c4eb8188b68d', 'mrgoshz@rmune.com', '2022-04-25 03:03:03');



INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('5be5da98-6c6a-4510-b13a-c01267ceac61',  0,  'andrewng13@mercantravellers.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '4217e902-7b69-419e-813c-07a54c1fd71b', 'mglbm1@angelleon.art', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('bd9b9ecf-314d-49b1-9b17-32aefec2453d',  0,  'jalun1988@edus.works', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '58f326b3-db91-4527-bf0a-0e1a7bedfae4', 'leemacca@lohpcn.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('2e5d445b-1830-42de-98fe-bbdd9ca625cc',  0,  'sierra248@greendike.com', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '552ec6b1-bd1c-4549-8eec-d557b09493ff', 'danielraddock@gmx.fit', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('1bdefd6a-ae8b-4cb4-987b-a7268e11c23f',  0, 'marinagalytskaya@hs-gilching.de', '2022-03-28 03:03:03', '00000000-0000-0000-0000-000000000000', '2977f88c-7dc9-4233-b339-dd0afac32ece', 'thx3281@teeoli.com', '2022-04-25 03:03:03');



INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('3ae366c7-80c5-45c2-b47f-ffab3393e9ce', 0, 'rbos51@aihtnb.com', '2022-03-28 03:03:03', '0d76ddc7-19de-438d-a4bd-9861e2aa5ab5', 'e8404447-1f92-480c-b7d0-58ed45f1751e', 'eyk68@taatfrih.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date)
  VALUES('0aa9657a-75be-451b-87cf-5ba9a8c796e2', 0, 'oslek0511@piftir.com', '2022-03-28 03:03:03', 'ca7df766-3635-459c-b7b0-1daf69c4e491', 'f953e97c-3f6d-479b-ba26-67d99ee3bbd4', 'irihkafew@sungkian.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('7f34f91f-3b78-41e4-b8ac-6a28107d2542', 0, 'bleatham@longaitylo.com', '2022-03-28 03:03:03', 'ba05c963-713a-49e9-957d-d9c4867623b0', '53788f0e-67ef-4039-9d62-ef5bf722f2bf', 'johnwea1@onlinecmail.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('029cab8f-04f3-415e-a245-6198604b7038', 0, 'akl111@tchoeo.com', '2022-03-28 03:03:03', '0d76ddc7-19de-438d-a4bd-9861e2aa5ab5', '87b7a694-c905-48fa-8886-5c6f98b6c15b', 'jamsims12@isueir.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('2723fa17-c9d5-41fb-88eb-5136fdd7f957', 0, 'emus123@readog.site', '2022-03-28 03:03:03', 'ca7df766-3635-459c-b7b0-1daf69c4e491', '045e2173-5773-4a2f-899f-2f1f72dba7fa', 'dravid15@bestiengine.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date)
  VALUES('37227c99-ccd9-4ce7-807e-6cdaa0747d2e', 0, 'bahnknotenpunkt@ibnlolpla.com', '2022-03-28 03:03:03', 'ba05c963-713a-49e9-957d-d9c4867623b0', '07535e94-e612-474f-a8b8-927b4896f6e2', 'kelters@eeuasi.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('19092f60-5112-4701-85f9-8e6010528b24', 0, 'fatimatag@nieise.com', '2022-03-28 03:03:03', '0d76ddc7-19de-438d-a4bd-9861e2aa5ab5', '11972e86-6b21-4804-8f24-d8dc7d39ff7a', 'cynagn@thumbthingshiny.net', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('2caf0316-2e98-4622-b794-a0ad6f05822e', 0, 'nantua33@netveplay.com', '2022-03-28 03:03:03', 'ca7df766-3635-459c-b7b0-1daf69c4e491', '970d0adf-9837-433b-9a75-8eebf4b51d25', 'ezichi@cuedigy.com', '2022-04-25 03:03:03');

  
  
  
INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('a05664b4-08f5-4f11-ace0-dd2b68245b7d', 0, 'rbos51@aihtnb.com', '2022-03-28 03:03:03', '24b97dcf-99e4-4adc-b6bc-777a497c22a9', '844104ab-3d87-41d7-b537-a68f0c3dd8a4', 'eyk68@taatfrih.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date)
  VALUES('c78a7fb1-1b40-4558-9300-041644ecff7c', 0, 'oslek0511@piftir.com', '2022-03-28 03:03:03', 'f979804b-87ed-49a2-9d36-db75f5435841', 'ab47cf00-066f-4c5b-9eed-43a6a23f62f0', 'irihkafew@sungkian.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('6f78b43c-254f-4ce3-a90a-c1cd78d48a44', 0, 'bleatham@longaitylo.com', '2022-03-28 03:03:03', '8cbd2c35-a1fc-4e0b-9d9c-80a8e041d6fe', '6f79068d-955e-43bb-89ed-b3998cfc63ac', 'johnwea1@onlinecmail.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('a701fb69-319e-4ef7-af7f-e20909847dc0', 0, 'akl111@tchoeo.com', '2022-03-28 03:03:03', '3adf59bd-1c00-4933-8493-5e7fb5d411a2', 'bdba51bf-bc7f-47fd-89a9-05baac3621f3', 'jamsims12@isueir.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('1ce1785a-e084-4149-afdb-b8c1bf94b993', 0, 'emus123@readog.site', '2022-03-28 03:03:03', '24b97dcf-99e4-4adc-b6bc-777a497c22a9', '9a16aa02-c77f-4817-a7b7-9b0f154e3042', 'dravid15@bestiengine.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date)
  VALUES('916c83c1-2d2e-4e48-bcd2-28c8c9324d80', 0, 'bahnknotenpunkt@ibnlolpla.com', '2022-03-28 03:03:03', 'f979804b-87ed-49a2-9d36-db75f5435841', '76902450-b163-43a8-9abe-f0b4a60d72d3', 'kelters@eeuasi.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('13f4d122-8153-459f-956c-3c6e155020c1', 0, 'fatimatag@nieise.com', '2022-03-28 03:03:03', '8cbd2c35-a1fc-4e0b-9d9c-80a8e041d6fe', '9ad63e30-0527-4f2a-9873-714f54d869bf', 'cynagn@thumbthingshiny.net', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('926ff12d-f534-485c-a916-425b9c725429', 0, 'nantua33@netveplay.com', '2022-03-28 03:03:03', '3adf59bd-1c00-4933-8493-5e7fb5d411a2', 'e0d5267e-6519-450e-aacd-ef53c996f21d', 'ezichi@cuedigy.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date)
  VALUES('08eef7ce-3cbc-431e-a16f-1f54c9c780b1', 0, 'dennkonn@hstuie.com', '2022-03-28 03:03:03', '24b97dcf-99e4-4adc-b6bc-777a497c22a9', '19cb816a-7390-4c3e-b095-769926b37bd9', 'boblil@onlinecmail.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('d9d3258a-4c00-4322-99de-a45acd3ce650', 0, 'lovely28@colevillecapital.com', '2022-03-28 03:03:03', 'f979804b-87ed-49a2-9d36-db75f5435841', '9d9fb4cc-ef50-4c57-b10e-c4eb8188b68d', 'vvvfdsa@hunaig.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('ff2489e9-82aa-46b7-8ee2-694c2d0fc145', 0, 'rrackley@zipeq.site', '2022-03-28 03:03:03', '8cbd2c35-a1fc-4e0b-9d9c-80a8e041d6fe', '4217e902-7b69-419e-813c-07a54c1fd71b', 'nosoknatali@bomukic.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date )
  VALUES('68d542bf-4f70-4854-8dc4-b04d1b56e2e0', 0, 'fjtp@netveplay.com', '2022-03-28 03:03:03', '3adf59bd-1c00-4933-8493-5e7fb5d411a2', '58f326b3-db91-4527-bf0a-0e1a7bedfae4', 'lamacena@eetieg.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date)
  VALUES('4cbd02d8-71d9-4d8d-951c-a942cc543f11', 0, 'switty0305@aenikaufa.com', '2022-03-28 03:03:03', '24b97dcf-99e4-4adc-b6bc-777a497c22a9', '552ec6b1-bd1c-4549-8eec-d557b09493ff', 'jbonigh@teeenye.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_id, last_modified_by, last_modified_date)
  VALUES('50977c0c-9393-4fc1-9509-b1b63651681c', 0, 'vanillaky@boranora.com', '2022-03-28 03:03:03', 'f979804b-87ed-49a2-9d36-db75f5435841', '2977f88c-7dc9-4233-b339-dd0afac32ece', 'frauderen@hisukamie.com', '2022-04-25 03:03:03');
