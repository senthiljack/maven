INSERT INTO user_gapi.users(id, version, email, first_name, last_name, phone, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('080ed885-9d0e-42a6-9722-96713ff7a0fd',  0, 'phantomtest12@gmail.com', 'Jyostna', 'Eustice', '2345678123', 'ACTIVE', '2022-03-24 03:03:03', 'REJECTED', '2022-03-24 03:03:03', 'shevadiman@networkofemail.com', '2022-03-24 03:03:03', 'unknown','johnwea1@onlinecmail.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date )
  VALUES('7efff47a-4f2c-44c9-96e7-f330f1c5df7e',  0, 'roosterj@nkgursr.com', '2022-03-28 03:03:03', '0012E00002dzucpQAA', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', '080ed885-9d0e-42a6-9722-96713ff7a0fd', 'aeajyz@aenikaufa.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_role_assets(id, user_account_id) 
  VALUES('32c43c62-b634-41ba-8c8e-54439ed4d8ae', '7efff47a-4f2c-44c9-96e7-f330f1c5df7e');

INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_role_assets_id, last_modified_by, last_modified_date )
  VALUES('416dd2be-2ede-4f38-9a45-5a85cc874158', 1, 'mehrfragen@zdbgjajg.shop', '2022-03-28 03:03:03', 'unknown', '32c43c62-b634-41ba-8c8e-54439ed4d8ae', 'martinn19@mymailcr.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_role_assets_id, last_modified_by, last_modified_date )
  VALUES('a6e97a09-86ac-435a-8693-fda9c430c159', 0, 'rbos51@aihtnb.com', '2022-03-28 03:03:03', '02efcb2c-873e-4e86-93ac-665229bac164', '32c43c62-b634-41ba-8c8e-54439ed4d8ae', 'eyk68@taatfrih.com', '2022-04-25 03:03:03');




INSERT INTO user_gapi.users(id, version, email, first_name, last_name, phone, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('92514648-2d82-4cb3-9ea1-c131528188a2',  0, 'phantom.aao.dlr@gmail.com', 'Swara', 'Eustice', '2345678123', 'ACTIVE', '2022-03-24 03:03:03', 'REJECTED', '2022-03-24 03:03:03', 'shevadiman@networkofemail.com', '2022-03-24 03:03:03', 'unknown','johnwea1@onlinecmail.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date )
  VALUES('c2018833-ff3b-4ab8-8777-059b10dc0ceb',  0, 'roosterj@nkgursr.com', '2022-03-28 03:03:03', '0012E00002dzucpQAA', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', '92514648-2d82-4cb3-9ea1-c131528188a2', 'aeajyz@aenikaufa.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_role_assets(id, user_account_id) 
  VALUES('f5f66c12-efff-4567-8490-d49a1e9d38f3', 'c2018833-ff3b-4ab8-8777-059b10dc0ceb');

INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_role_assets_id, last_modified_by, last_modified_date )
  VALUES('775df465-c4bd-4eeb-abb7-f3d5d7d46852', 1, 'mehrfragen@zdbgjajg.shop', '2022-03-28 03:03:03', 'unknown', 'f5f66c12-efff-4567-8490-d49a1e9d38f3', 'martinn19@mymailcr.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_role_assets_id, last_modified_by, last_modified_date )
  VALUES('8078b1f5-aeb2-4154-9e81-453180bd7e4b', 0, 'rbos51@aihtnb.com', '2022-03-28 03:03:03', '02efcb2c-873e-4e86-93ac-665229bac164', 'f5f66c12-efff-4567-8490-d49a1e9d38f3', 'eyk68@taatfrih.com', '2022-04-25 03:03:03');




INSERT INTO user_gapi.users(id, version, email, first_name, last_name, phone, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('f8e8ca83-ad6c-452b-8d00-50d5f43f442a',  0, 'globalportal@outlook.com', 'Moni', 'Eustice', '2345678123', 'ACTIVE', '2022-03-24 03:03:03', 'REJECTED', '2022-03-24 03:03:03', 'shevadiman@networkofemail.com', '2022-03-24 03:03:03', 'unknown','johnwea1@onlinecmail.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date )
  VALUES('2d6ce962-5c51-423e-ae74-c22fb1a0d285',  0, 'roosterj@nkgursr.com', '2022-03-28 03:03:03', '0012E00002dzucpQAA', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', 'f8e8ca83-ad6c-452b-8d00-50d5f43f442a', 'aeajyz@aenikaufa.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_role_assets(id, user_account_id) 
  VALUES('1cbcfdfc-9c45-4d83-8373-fa3f45992176', '2d6ce962-5c51-423e-ae74-c22fb1a0d285');

INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_role_assets_id, last_modified_by, last_modified_date )
  VALUES('783a7ccc-3990-477c-a35d-57c0d165830f', 1, 'mehrfragen@zdbgjajg.shop', '2022-03-28 03:03:03', 'unknown', '1cbcfdfc-9c45-4d83-8373-fa3f45992176', 'martinn19@mymailcr.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_role_assets_id, last_modified_by, last_modified_date )
  VALUES('379b719b-ebbb-4dfd-8271-01e9a92897c1', 0, 'rbos51@aihtnb.com', '2022-03-28 03:03:03', '86893f2e-834a-42c4-9ad7-9a8b90cdcd40', '1cbcfdfc-9c45-4d83-8373-fa3f45992176', 'eyk68@taatfrih.com', '2022-04-25 03:03:03');




INSERT INTO user_gapi.users(id, version, email, first_name, last_name, phone, status, status_change_date, terms_and_conditions_status, terms_and_conditions_date, created_by, created_date, terms_and_conditions_version, last_modified_by, last_modified_date ) 
  VALUES('5f101317-8391-4e64-9099-a9ec386e4f98',  0, 'admin@digitalrealty.com', 'Sakshi', 'Eustice', '2345678123', 'ACTIVE', '2022-03-24 03:03:03', 'REJECTED', '2022-03-24 03:03:03', 'shevadiman@networkofemail.com', '2022-03-24 03:03:03', 'unknown','johnwea1@onlinecmail.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account(id, version, created_by, created_date, legal_entity_key, approval_status, default_account, any_account, status, status_changed_date, user_id, last_modified_by, last_modified_date )
  VALUES('3f39091b-f8e9-4e75-b833-acf1227a0092',  0, 'roosterj@nkgursr.com', '2022-03-28 03:03:03', '0012E00002dzucpQAA', 'APPROVED', 1, 1, 'ACTIVE', '2022-03-28 03:03:03', '5f101317-8391-4e64-9099-a9ec386e4f98', 'aeajyz@aenikaufa.com', '2022-04-25 03:03:03');


INSERT INTO user_gapi.user_account_role_assets(id, user_account_id) 
  VALUES('a18da2ef-b659-416a-83a6-ed77c9b7f814', '3f39091b-f8e9-4e75-b833-acf1227a0092');

INSERT INTO user_gapi.user_account_asset(id, version, created_by, created_date, asset_id, user_account_role_assets_id, last_modified_by, last_modified_date )
  VALUES('2768f4aa-d93f-4bc2-95f5-c99bea27dd3f', 1, 'mehrfragen@zdbgjajg.shop', '2022-03-28 03:03:03', 'unknown', 'a18da2ef-b659-416a-83a6-ed77c9b7f814', 'martinn19@mymailcr.com', '2022-04-25 03:03:03');

INSERT INTO user_gapi.user_account_role(id, version, created_by, created_date, role_id, user_account_role_assets_id, last_modified_by, last_modified_date )
  VALUES('a955f6f4-9ccb-406a-8325-1a4e92736575', 0, 'rbos51@aihtnb.com', '2022-03-28 03:03:03', 'c6e20633-672f-4d39-b2c3-c7a521b94f3d', 'a18da2ef-b659-416a-83a6-ed77c9b7f814', 'eyk68@taatfrih.com', '2022-04-25 03:03:03');



