DROP TABLE "user_gapi"."user_account_role";
DROP TABLE "user_gapi"."user_account_asset";


CREATE TABLE "user_gapi"."user_account_role_assets" (
    "id" VARCHAR(255) NOT NULL PRIMARY KEY,
    "user_account_id" VARCHAR(255)
);


CREATE TABLE "user_gapi"."user_account_asset" (
    "id" VARCHAR(255) NOT NULL PRIMARY KEY,
    "created_by" VARCHAR(255),
    "created_date" DATETIME,
    "last_modified_by" VARCHAR(255),
    "last_modified_date" DATETIME,
    "version" INTEGER NOT NULL,
    "asset_id" VARCHAR(255),
    "site_path" VARCHAR(255),
    "user_account_role_assets_id" VARCHAR(255) NOT NULL,
    CONSTRAINT FK_UserAccountAsset FOREIGN KEY (user_account_role_assets_id) REFERENCES "user_gapi"."user_account_role_assets" (id)
);


CREATE TABLE "user_gapi"."user_account_role"(
    "id" VARCHAR(255) NOT NULL PRIMARY KEY,
    "created_by" VARCHAR(255),
    "created_date" DATETIME,
    "last_modified_by" VARCHAR(255),
    "last_modified_date" DATETIME,
    "version" INTEGER NOT NULL,
    "role_id" VARCHAR(255) NOT NULL,
    "user_account_role_assets_id" VARCHAR(255) NOT NULL,
    CONSTRAINT FK_UserAccountRole FOREIGN KEY (user_account_role_assets_id) REFERENCES "user_gapi"."user_account_role_assets" (id)
);
CREATE UNIQUE INDEX user_account_role_useraccount_id_role_id ON "user_gapi"."user_account_role" (user_account_role_assets_id, role_id);