
CREATE TABLE "user_gapi"."super_user" (
    "email" VARCHAR(255) NOT NULL PRIMARY KEY
);


CREATE TABLE "user_gapi"."users" (
    "id" VARCHAR(255) NOT NULL PRIMARY KEY,
    "created_by" VARCHAR(255),
    "created_date" DATETIME,
    "last_modified_by" VARCHAR(255),
    "last_modified_date" DATETIME,
    "version" INTEGER NOT NULL,
    "email" VARCHAR(255) NOT NULL,
    "first_name" VARCHAR(255) NOT NULL,
    "last_name" VARCHAR(255) NOT NULL,
    "phone" VARCHAR(255) NOT NULL,
    "position" VARCHAR(255) NOT NULL,
    "status" VARCHAR(100) NOT NULL,
    "internal_status" VARCHAR(100) DEFAULT 'NEED_SYNC' NOT NULL,
    "status_change_date" DATETIME,
    "terms_and_conditions_status" VARCHAR(100),
    "terms_and_conditions_date" DATETIME,
    "terms_and_conditions_version" VARCHAR(255)
);
CREATE INDEX users_email ON "user_gapi"."users" (email);
CREATE INDEX users_status ON "user_gapi"."users" (status);


CREATE TABLE "user_gapi"."user_account" (
    "id" VARCHAR(255) NOT NULL PRIMARY KEY,
    "created_by" VARCHAR(255),
    "created_date" DATETIME,
    "last_modified_by" VARCHAR(255),
    "last_modified_date" DATETIME,
    "version" INTEGER NOT NULL,
    "legal_entity_key" VARCHAR(100),
    "approval_status"  VARCHAR(100) NOT NULL,
    "default_account" BIT,
    "any_account" BIT DEFAULT 0 NOT NULL, 
    "status"  VARCHAR(100) NOT NULL,
    "status_changed_date" DATETIME NOT NULL,
    "user_id" VARCHAR(255) NOT NULL,
    CONSTRAINT FK_UserAccountUser FOREIGN KEY (user_id) REFERENCES "user_gapi"."users" (id)
);
CREATE INDEX useraccount_user_id ON "user_gapi"."user_account" (user_id);
CREATE INDEX useraccount_status ON "user_gapi"."user_account" (status);


CREATE TABLE "user_gapi"."user_account_asset" (
    "id" VARCHAR(255) NOT NULL PRIMARY KEY,
    "created_by" VARCHAR(255),
    "created_date" DATETIME,
    "last_modified_by" VARCHAR(255),
    "last_modified_date" DATETIME,
    "version" INTEGER NOT NULL,
    "asset_id" VARCHAR(255) NOT NULL,
    "user_account_id" VARCHAR(255) NOT NULL,
    CONSTRAINT FK_UserAccountAsset FOREIGN KEY (user_account_id) REFERENCES "user_gapi"."user_account" (id)
);
CREATE INDEX useraccountasset_useraccountid ON "user_gapi"."user_account_asset" (user_account_id);


CREATE TABLE "user_gapi"."user_account_role"(
    "id" VARCHAR(255) NOT NULL PRIMARY KEY,
    "created_by" VARCHAR(255),
    "created_date" DATETIME,
    "last_modified_by" VARCHAR(255),
    "last_modified_date" DATETIME,
    "version" INTEGER NOT NULL,
    "role_id" VARCHAR(255) NOT NULL,
    "user_account_id" VARCHAR(255) NOT NULL,
    CONSTRAINT FK_UserAccountRole FOREIGN KEY (user_account_id) REFERENCES "user_gapi"."user_account" (id)
);
CREATE INDEX useraccountrole_useraccountid ON "user_gapi"."user_account_role" (user_account_id);


-- Auditing tables
CREATE TABLE "user_gapi"."revinfo" (
    "rev" integer NOT NULL IDENTITY(1,1) PRIMARY KEY,
    "revtstmp" BIGINT
);


CREATE TABLE "user_gapi"."user_account_asset_aud"(
    "id" VARCHAR(255) NOT NULL,
    "rev" INTEGER NOT NULL,
    "revtype" TINYINT,
    "asset_id" VARCHAR(255),
    "user_account_id" VARCHAR(255),
    PRIMARY KEY ("id", "rev"),
    CONSTRAINT FK_UserAccountAssetAud FOREIGN KEY (rev) REFERENCES "user_gapi"."revinfo" (rev)
);


CREATE TABLE "user_gapi"."user_account_aud"(
    "id" VARCHAR(255) NOT NULL,
    "rev" INTEGER NOT NULL,
    "revtype" TINYINT,
    "legal_entity_key" VARCHAR(100) NOT NULL,
    "approval_status" VARCHAR(100),
    "default_account" BIT,
    "any_account" BIT,    
    "status" VARCHAR(100) NOT NULL,
    "status_changed_date" DATETIME NOT NULL,
    "user_id" VARCHAR(255),
    PRIMARY KEY ("id", "rev"),
    CONSTRAINT FK_UserAccountAud FOREIGN KEY (rev) REFERENCES "user_gapi"."revinfo" (rev)
);


CREATE TABLE "user_gapi"."user_account_role_aud"(
    "id" VARCHAR(255) NOT NULL,
    "rev" INTEGER NOT NULL,
    "revtype" TINYINT,
    "role_id" VARCHAR(255) NOT NULL,
    "user_account_id" VARCHAR(255) NOT NULL,
    PRIMARY KEY ("id", "rev"),
    CONSTRAINT FK_UserAccountRoleAud FOREIGN KEY (rev) REFERENCES "user_gapi"."revinfo" (rev)
);


CREATE TABLE "user_gapi"."users_aud"(
    "id" VARCHAR(255) NOT NULL,
    "rev" INTEGER NOT NULL,
    "revtype" TINYINT,
    "email" VARCHAR(255) NOT NULL,
    "first_name" VARCHAR(255) NOT NULL,
    "last_name" VARCHAR(255) NOT NULL,
    "phone" VARCHAR(255) NOT NULL,
    "position" VARCHAR(255),
    "status" VARCHAR(100),
    "internal_status" VARCHAR(100) DEFAULT 'NEED_SYNC' NOT NULL,
    "status_change_date" DATETIME NOT NULL,
    "terms_and_conditions_status" VARCHAR(100),
    "terms_and_conditions_date" DATETIME,
    "terms_and_conditions_version" VARCHAR(255),
    PRIMARY KEY ("id", "rev"),
    CONSTRAINT FK_UserAud FOREIGN KEY (rev) REFERENCES "user_gapi"."revinfo" (rev)
);