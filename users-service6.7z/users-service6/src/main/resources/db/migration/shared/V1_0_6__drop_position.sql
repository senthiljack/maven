ALTER TABLE "user_gapi"."users" DROP COLUMN "position";
ALTER TABLE "user_gapi"."users_aud" DROP COLUMN "position";