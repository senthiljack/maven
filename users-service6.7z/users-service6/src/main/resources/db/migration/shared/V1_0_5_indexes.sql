CREATE UNIQUE INDEX super_user_email_idx ON "user_gapi"."super_user" (email);
DROP INDEX IF EXISTS users_email ON "user_gapi"."users";
CREATE UNIQUE INDEX users_email_idx ON "user_gapi"."users" (email);
DROP INDEX IF EXISTS users_status ON "user_gapi"."users";
CREATE INDEX users_status_idx ON "user_gapi"."users" (status);
CREATE INDEX users_id_email_status_idx ON "user_gapi"."users" (id, email, status);
CREATE INDEX users_internal_status_exec_id_idx ON "user_gapi"."users" (internal_status, execution_id);
CREATE INDEX users_internal_exec_id_last_md_idx ON "user_gapi"."users" (execution_id, last_modified_date);
CREATE INDEX users_internal_exec_id_idx ON "user_gapi"."users" (execution_id);

DROP INDEX IF EXISTS useraccount_user_id ON "user_gapi"."user_account";
DROP INDEX IF EXISTS useraccount_status ON "user_gapi"."user_account";

CREATE UNIQUE INDEX user_account_user_id_le_key_idx ON "user_gapi"."user_account" (user_id, legal_entity_key);
CREATE INDEX user_account_user_id_idx ON "user_gapi"."user_account" (user_id);
CREATE INDEX user_account_status_idx ON "user_gapi"."user_account" (status);
CREATE INDEX user_account_status_changed_date_idx ON "user_gapi"."user_account" (status_changed_date);
CREATE INDEX user_account_id_le_key_status_idx ON "user_gapi"."user_account" (id, legal_entity_key, status);

DROP INDEX IF EXISTS useraccountasset_useraccountid ON "user_gapi"."user_account_asset" ;
CREATE UNIQUE INDEX user_account_asset_useraccount_id_asset_id_idx ON "user_gapi"."user_account_asset" (user_account_id, asset_id);

DROP INDEX IF EXISTS useraccountrole_useraccountid  ON "user_gapi"."user_account_role" ;
CREATE UNIQUE INDEX user_account_role_useraccount_id_role_id ON "user_gapi"."user_account_role" (user_account_id, role_id);

/*
DROP INDEX IF EXISTS super_user_email_idx ON "user_gapi"."super_user";
DROP INDEX IF EXISTS users_email_idx ON "user_gapi"."users";
DROP INDEX IF EXISTS users_status_idx ON "user_gapi"."users";
DROP INDEX IF EXISTS users_id_email_status_idx ON "user_gapi"."users";
DROP INDEX IF EXISTS users_internal_status_exec_id_idx ON "user_gapi"."users";
DROP INDEX IF EXISTS users_internal_exec_id_last_md_idx ON "user_gapi"."users";
DROP INDEX IF EXISTS users_internal_exec_id_idx ON "user_gapi"."users";
DROP INDEX IF EXISTS user_account_user_id_le_key_idx ON "user_gapi"."user_account";
DROP INDEX IF EXISTS user_account_user_id_idx ON "user_gapi"."user_account";
DROP INDEX IF EXISTS user_account_status_idx ON "user_gapi"."user_account";
DROP INDEX IF EXISTS user_account_status_changed_date_idx ON "user_gapi"."user_account";
DROP INDEX IF EXISTS user_account_id_le_key_status_idx ON "user_gapi"."user_account";
DROP INDEX IF EXISTS user_account_asset_useraccount_id_asset_id_idx ON "user_gapi"."user_account_asset";
DROP INDEX IF EXISTS user_account_role_useraccount_id_role_id ON "user_gapi"."user_account_role";
*/