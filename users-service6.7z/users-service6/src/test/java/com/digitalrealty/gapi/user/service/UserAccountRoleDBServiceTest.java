package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.mapper.UserAccountRoleMapper;
import com.digitalrealty.gapi.user.model.IUserAccountRole;
import com.digitalrealty.gapi.user.repository.UserAccountRoleRepository;

@ExtendWith(MockitoExtension.class)
public class UserAccountRoleDBServiceTest {

	@Mock
	UserAccountRoleRepository userAccountRoleRepository;

	@Mock
	UserAccountRoleMapper userAccountRoleMapper;

	@InjectMocks
	UserAccountRoleDBService userAccountRoleDBService;

	@Test
	void findByRoleIdTest() {
		when(userAccountRoleRepository.findByRoleId(TestConfiguration.roleId)).thenReturn(Stream.of(TestConfiguration.getIUserAccountRole()).collect(Collectors.toList()));

		List<IUserAccountRole> userAccountRoleList = userAccountRoleDBService.findByRoleId(TestConfiguration.roleId);

		assertThat(userAccountRoleList.get(0).getRoleId()).isEqualTo(TestConfiguration.roleId);
		verify(userAccountRoleRepository, times(1)).findByRoleId(TestConfiguration.roleId);
	}

	@Test
	void findByUserAccountIdTest() {
		when(userAccountRoleRepository.findByUserAccountId(TestConfiguration.getUserAccount().getId())).thenReturn(Stream.of(TestConfiguration.getIUserAccountRole()).collect(Collectors.toList()));

		List<IUserAccountRole> userAccountRoleList = userAccountRoleDBService.findByUserAccountId(TestConfiguration.getUserAccount().getId());

		assertThat(userAccountRoleList.get(0).getRoleId()).isEqualTo(TestConfiguration.getUserAccountRoleEntity().getRoleId());
		verify(userAccountRoleRepository, times(1)).findByUserAccountId(TestConfiguration.getUserAccount().getId());
	}

}