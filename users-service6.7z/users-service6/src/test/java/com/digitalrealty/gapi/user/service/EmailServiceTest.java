package com.digitalrealty.gapi.user.service;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.configuration.UserConfig;

@ExtendWith(MockitoExtension.class)
public class EmailServiceTest {

	@Mock
	WebClient webClient;

	@Mock
	UserConfig userConfig;

	@Mock
	UserDBService userDBService;

	@InjectMocks
	EmailService emailService;

	@Test
	public void notifySyncedUsersTest() throws Exception {
		when(userDBService.saveUsers(Mockito.anyList())).thenReturn(Stream.of(TestConfiguration.getUser()).collect(Collectors.toList()));

		emailService.notifySyncedUsers(Stream.of(TestConfiguration.getUser()).collect(Collectors.toList()));

		verify(userDBService, times(1)).saveUsers(Mockito.anyList());
	}

}
