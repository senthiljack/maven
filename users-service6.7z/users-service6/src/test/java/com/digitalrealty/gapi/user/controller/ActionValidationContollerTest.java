package com.digitalrealty.gapi.user.controller;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.service.AuthorizationService;
import com.digitalrealty.gapi.user.service.UserAccountRoleService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class ActionValidationContollerTest {

	@Mock
	AuthorizationService authorizationService;

	@Mock
	UserAccountRoleService userAccountRoleService;

	@InjectMocks
	ActionValidationContoller actionValidationContoller;

	@Test
	void validateAction() throws Exception {
		actionValidationContoller.validateAction(TestConfiguration.getActionValidationRequest());

		verify(authorizationService, times(1)).isAuthorized(TestConfiguration.getActionValidationRequest());
	}

	@Test
	void validateRole() throws Exception {
		actionValidationContoller.validateRole(TestConfiguration.roleId);

		verify(userAccountRoleService, times(1)).validateUserRole(TestConfiguration.roleId);
	}
}
