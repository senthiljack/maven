package com.digitalrealty.gapi.user.mapper;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.entity.UserAccountRoleEntity;
import com.digitalrealty.gapi.user.model.UserAccountRole;

@ExtendWith(MockitoExtension.class)
public class UserAccountRoleMapperTest {

	@Mock
	MappingUtil mappingUtil;

	@InjectMocks
	UserAccountRoleMapper userAccountRoleMapper = Mappers.getMapper(UserAccountRoleMapper.class);

	@Test
	public void mapUserAccountRoleEntityToUserAccountRoleTest() {
		UserAccountRole userAccountRole = userAccountRoleMapper.map(TestConfiguration.getUserAccountRoleEntity());
		assertThat(userAccountRole.getRoleId()).isEqualTo(TestConfiguration.getUserAccountRoleEntity().getRoleId());
	}

	@Test
	public void mapUserAccountRoleToUserAccountRoleEntityTest() {
		UserAccountRoleEntity userAccountRoleEntity = userAccountRoleMapper.map(TestConfiguration.getUserAccountRole());

		assertThat(userAccountRoleEntity.getRoleId()).isEqualTo(TestConfiguration.getUserAccountRole().getRoleId());
	}
}
