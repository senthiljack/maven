package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.common.context.ContextUtility;
import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.mapper.UserMapper;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.payloadmodel.UserCreateResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserProfileResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserUpdateResponse;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

	@Mock
	ContextUtility contextUtility;

	@Mock
	IdpService idpService;

	@Mock
	SnowService snowService;

	@Mock
	EmailService emailService;

	@Mock
	EncryptionService encryptionService;

	@Mock
	UserDBService userDBService;

	@Mock
	UserMapper userMapper;

	@Mock
	AuthorizationService authorizationService;

	@Mock
	JmsUserService jmsUserService;
	
	@Mock
	AccountService accountService;

	@InjectMocks
	UserService userService;

	@Test
	public void createUserRequest() {
		UserCreateResponse userCreateResponse = TestConfiguration.getCreateUserResponse();
		userCreateResponse.setId(TestConfiguration.userId);

		when(userDBService.createUser(TestConfiguration.getCreateUserRequest())).thenReturn(TestConfiguration.getUser());
		when(userMapper.mapUserToCreateUserResponse(TestConfiguration.getUser())).thenReturn(userCreateResponse);

		UserCreateResponse createUserResponse = userService.createUser(TestConfiguration.getCreateUserRequest());

		assertThat(createUserResponse.getFirstName()).isEqualTo(TestConfiguration.getCreateUserRequest().getFirstName());
		verify(userDBService, times(1)).createUser(TestConfiguration.getCreateUserRequest());
	}

	@Test
	public void updateUser() {
		UserUpdateResponse userUpdate = TestConfiguration.getUserUpdateResponse();
		userUpdate.setId(TestConfiguration.userId);

		when(userDBService.updateUser(TestConfiguration.getUser().getId(), TestConfiguration.getUserUpdateRequest())).thenReturn(TestConfiguration.getUser());
		when(userMapper.mapUserToUpdateUserRequest(TestConfiguration.getUser())).thenReturn(userUpdate);

		UserUpdateResponse userUpdateResponse = userService.updateUser(TestConfiguration.getUser().getId(), TestConfiguration.getUserUpdateRequest());

		assertThat(userUpdateResponse.getFirstName()).isEqualTo(TestConfiguration.getUserUpdateRequest().getFirstName());
		verify(userDBService, times(1)).updateUser(TestConfiguration.getUser().getId(), TestConfiguration.getUserUpdateRequest());
	}

	@Test
	public void getUser() {
		when(userDBService.findById(TestConfiguration.getUser().getId())).thenReturn(TestConfiguration.getUser());
		when(userMapper.mapUserToUserRetrieveResponse(TestConfiguration.getUser())).thenReturn(TestConfiguration.getUserProfileResponse());

		UserProfileResponse userProfileResponse = userService.getUser(TestConfiguration.getUser().getId());

		assertThat(userProfileResponse.getFirstName()).isEqualTo(TestConfiguration.getCreateUserRequest().getFirstName());
		verify(userDBService, times(1)).findById(TestConfiguration.getUser().getId());
	}

	@Test
	public void maintainTermsConditions() {
		when(encryptionService.encryptEmail(ContextUtility.UNSPECIFIED)).thenReturn(TestConfiguration.getSuperUserEntity().getEmail());
		when(userDBService.saveTermsAndConditions(TestConfiguration.getSuperUserEntity().getEmail(), TestConfiguration.getTermsConditionsRequest())).thenReturn(TestConfiguration.getUser());

		userService.maintainTermsConditions(TestConfiguration.getTermsConditionsRequest());

		verify(userDBService, times(1)).saveTermsAndConditions(TestConfiguration.getSuperUserEntity().getEmail(), TestConfiguration.getTermsConditionsRequest());
	}

	@Test
	public void getUsers() {
		when(userDBService.findById(TestConfiguration.getUser().getId())).thenReturn(TestConfiguration.getUser());

		userService.getUser(TestConfiguration.getUser().getId());
		verify(userDBService, times(1)).findById(TestConfiguration.getUser().getId());
	}

	@Test
	public void synchronize() {
		userService.updateExternalSystems(Mockito.anyList());
		verify(idpService, times(1)).syncUsersToIdp(Mockito.anyList());
		verify(snowService, times(1)).syncUsersToSnow(Mockito.anyList());
		verify(emailService, times(1)).notifySyncedUsers(Mockito.anyList());
	}
	
	@Test
	void getDeletedUserAccountTest() {
		User user = TestConfiguration.getUserWithActiveStatus();
		user.setUserAccounts(Set.of(TestConfiguration.getUserAccount()));
		when(encryptionService.encryptEmail(anyString())).thenReturn("someEmailtxt");
		when(userDBService.findByEmail(anyString())).thenReturn(user);
		when(accountService.getLegalEntitiesForGU()).thenReturn(List.of(TestConfiguration.accountId));
		userService.getDeletedUserAccount();
		verify(userDBService, times(1)).getAllUsersWithDeletedAccountsForLE(List.of(TestConfiguration.accountId));
	}
}
