package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.jboss.logging.MDC;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.common.context.ContextFields;
import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.mapper.UserAccountAssetMapper;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssetResponse;

@ExtendWith(MockitoExtension.class)
public class UserAccountAssetServiceTest {

	@Mock
	UserAccountAssetMapper userAccountAssetMapper;

	@Mock
	UserDBService userDBService;

	@Mock
	SuperUserDBService superUserDBService;

	@Mock
	UserAccountDBService userAccountDBService;

	@Mock
	UserAccountAssetDBService userAccountAssetDBService;

	@Mock
	EncryptionService encryptionService;

	@InjectMocks
	UserAccountAssetService userAccountAssetService;

	@Test
	public void getUserAssetsTest() {
		MDC.put(ContextFields.LEGALENTITY, TestConfiguration.accountId.toString());

		when(encryptionService.encryptEmail(Mockito.anyString())).thenReturn(TestConfiguration.userEmail);
		when(userAccountDBService.findByUserEmailAndApprovalStatus(TestConfiguration.userEmail, ApprovalStatus.APPROVED)).thenReturn(Stream.of(TestConfiguration.getUserAccount()).collect(Collectors.toList()));
		when(userAccountAssetDBService.findIdsByUserAccountId(TestConfiguration.userAccountId)).thenReturn(Stream.of(TestConfiguration.getIUserAccountAsset()).collect(Collectors.toList()));

		UserAccountAssetResponse userAccountAssetResponse = userAccountAssetService.getUserAssets();

		assertThat(userAccountAssetResponse.getUserAccountAssets()).isNotNull();
		verify(userAccountAssetDBService, times(1)).findIdsByUserAccountId(TestConfiguration.userAccountId);
	}
}