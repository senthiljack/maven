package com.digitalrealty.gapi.user;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.digitalrealty.gapi.messaging.user.MaintainUserMessage;
import com.digitalrealty.gapi.messaging.user.UserRequestType;
import com.digitalrealty.gapi.user.entity.SuperUserEntity;
import com.digitalrealty.gapi.user.entity.UserAccountAssetEntity;
import com.digitalrealty.gapi.user.entity.UserAccountEntity;
import com.digitalrealty.gapi.user.entity.UserAccountRoleAssetsEntity;
import com.digitalrealty.gapi.user.entity.UserAccountRoleEntity;
import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.enums.InternalStatus;
import com.digitalrealty.gapi.user.enums.TermStatus;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;
import com.digitalrealty.gapi.user.enums.UserStatus;
import com.digitalrealty.gapi.user.mapper.UserObjectMapper;
import com.digitalrealty.gapi.user.model.ISuperUser;
import com.digitalrealty.gapi.user.model.IUserAccountAsset;
import com.digitalrealty.gapi.user.model.IUserAccountAssociation;
import com.digitalrealty.gapi.user.model.IUserAccountRole;
import com.digitalrealty.gapi.user.model.InsertUser;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.model.ValidateUserExists;
import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.AssetModel;
import com.digitalrealty.gapi.user.model.payloadmodel.IdpCreateUserRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.IdpCreateUserResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.IdpServiceTokenResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.RoleAssets;
import com.digitalrealty.gapi.user.model.payloadmodel.RoleCheckPermissionsRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.TermsConditionsRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountApprovalRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssetResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssetRoles;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssignmentRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssociations;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountRoleResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountStatusRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserCreateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserCreateResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserProfileResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserUpdateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserUpdateResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.ValidateLegalEntitiesResponse;
import com.digitalrealty.gapi.user.model.snow.SNowInsertUser;
import com.digitalrealty.gapi.user.model.snow.SNowUserAndCompanyAssets;
import com.digitalrealty.gapi.user.model.snow.SNowUserSysIdByEmail;
import com.digitalrealty.gapi.user.model.snow.SNowValidateUserExists;
import com.digitalrealty.gapi.user.model.snow.SnowCreateUserRequest;
import com.digitalrealty.gapi.user.model.snow.SnowCreateUserResponse;
import com.digitalrealty.gapi.user.model.snow.UserAndCompanyAssets;
import com.digitalrealty.gapi.user.model.snow.UserSysIdByEmail;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestConfiguration {

	public static final String superEmail = "admin@digitalrealty.com";

	public static final String userEmail = "john@doe.com";

	public static final UUID userId = UUID.fromString("b8f056bc-8224-428d-b3ca-98a3062c1052");

	public static final UUID userAccountId = UUID.fromString("865ef83f-5bf8-4b8e-8e96-e0a3cea6cc98");

	public static final UUID UserAccountRoleAssetsId = UUID.fromString("16a3e393-f77a-4a2e-a6a9-2d39c2e4cca9");

	public static final String assetId = "Example Asset ID";

	public static final UUID roleId = UUID.fromString("655ce123-1213-45eb-a9ee-1f941dfc8cf9");

	public static final String clientId = "dummy_client_id";

	public static final String clientSecret = "dummy_client_secret";

	public static final String grantType = "dummy_grant_type";

	public static final String localhost = "http://localhost:8080";

	public static final String accountId = "accountId 1";

	public static final List<String> actions = Arrays.asList("INTERNAL_USER", "EXTERNAL_USER");

	public static ObjectMapper userObjectMapper = new UserObjectMapper();

	public static User getUser() {
		return User.builder().id(userId).firstName("firstName").lastName("lastName").build();
	}

	public static IdpServiceTokenResponse getIdpServiceTokenResponse() {
		return IdpServiceTokenResponse.builder().expiresIn(3600).build();
	}

	public static User getUserWithCreatedStatus() {
		return User.builder().id(userId).firstName("firstName").lastName("lastName").status(UserStatus.CREATED).build();
	}

	public static User getUserWithActiveStatus() {
		return User.builder().id(userId).firstName("firstName").lastName("lastName").status(UserStatus.ACTIVE).build();
	}

	public static User getUserWithNotActiveStatus() {
		return User.builder().id(userId).firstName("firstName").lastName("lastName").status(UserStatus.NOTACTIVE).build();
	}

	public static IdpCreateUserRequest getIdpCreateUserRequest() {
		return IdpCreateUserRequest.builder().build();
	}

	public static IdpCreateUserResponse getIdpCreateUserResponse() {
		return IdpCreateUserResponse.builder().build();
	}

	public static SnowCreateUserRequest getSnowCreateUserRequest() {
		return SnowCreateUserRequest.builder().build();
	}

	public static SnowCreateUserResponse getSnowCreateUserResponse() {
		return SnowCreateUserResponse.builder().build();
	}

	public static ValidateLegalEntitiesResponse getValidateLegalEntitiesResponse() {
		return ValidateLegalEntitiesResponse.builder().erroredLegalEntityKeys(new ArrayList<String>()).build();
	}

	public static UserEntity getUserEntity() {
		UserEntity entity = new UserEntity("firstName", "lastName", "email", "phone", UserStatus.ACTIVE, InternalStatus.NEED_SYNC, TermStatus.ALERTED, Instant.parse("2022-02-16T10:47:08.494244100Z"), "version", Instant.parse("2022-03-16T10:47:08.494244100Z"), null);
		entity.setId(userId);
		return entity;
	}

	public static List<UserEntity> getUserEntityList() {
		List<UserEntity> userEntitiesList = new ArrayList<UserEntity>();
		UserEntity entity = new UserEntity("firstName", "lastName", "email", "phone", UserStatus.ACTIVE, InternalStatus.NEED_SYNC, TermStatus.ALERTED, Instant.parse("2022-02-16T10:47:08.494244100Z"), "version", Instant.parse("2022-03-16T10:47:08.494244100Z"), null);
		entity.setId(userId);
		userEntitiesList.add(entity);
		return userEntitiesList;
	}

	public static UserAccountRoleResponse getUserAccountRoleResponse() {
		return UserAccountRoleResponse.builder().superUser(false).userAccountRoles(Stream.of(roleId).collect(Collectors.toList())).build();
	}

	public static UserAccountAssetResponse getUserAccountAssetResponse() {
		return UserAccountAssetResponse.builder().superUser(false).userAccountAssets(Stream.of(new AssetModel(assetId, null)).collect(Collectors.toList())).build();
	}

	public static MaintainUserMessage getMaintainUserMessage() {
		return new MaintainUserMessage(userId, UserRequestType.CREATED);
	}

	public static UserCreateRequest getCreateUserRequest() {
		return UserCreateRequest.builder().firstName("firstName").lastName("lastName").email("a@a.com").build();
	}

	public static UserCreateResponse getCreateUserResponse() {
		return UserCreateResponse.builder().firstName("firstName").lastName("lastName").email("a@a.com").build();
	}

	public static UserUpdateRequest getUserUpdateRequest() {
		return UserUpdateRequest.builder().firstName("firstName").lastName("lastName").email("a@a.com").build();
	}

	public static UserUpdateResponse getUserUpdateResponse() {
		return UserUpdateResponse.builder().firstName("firstName").lastName("lastName").email("a@a.com").build();
	}

	public static UserProfileResponse getUserProfileResponse() {
		return UserProfileResponse.builder().firstName("firstName").lastName("lastName").email("a@a.com").build();
	}

	public static UserAccountStatusRequest getUserAccountStatusRequest() {
		Map<String, UserAccountStatus> associations = new HashMap<String, UserAccountStatus>() {
			private static final long serialVersionUID = 1L;
			{
				put(accountId, UserAccountStatus.ACTIVE);
			}
		};

		return UserAccountStatusRequest.builder().userAccounts(associations).build();
	}

	public static TermsConditionsRequest getTermsConditionsRequest() {
		return TermsConditionsRequest.builder().termsAndConditionsStatus(TermStatus.ACCEPTED).termsAndConditionsVersion("version-1").build();
	}

	public static UserAccountApprovalRequest getUserAccountApprovalRequest() {
		Map<UUID, ApprovalStatus> associations = new HashMap<UUID, ApprovalStatus>() {
			private static final long serialVersionUID = 1L;
			{
				put(userAccountId, ApprovalStatus.APPROVED);
			}
		};

		return UserAccountApprovalRequest.builder().userAccounts(associations).build();
	}

	public static UserAccountAssignmentRequest getUserAccountAssignmentRequest() {
		UserAccountAssetRoles uaAssetRoles = UserAccountAssetRoles.builder().anyAccount(false).legalEntityKey(accountId).associations(
				Stream.of(RoleAssets.builder().role(roleId).assets(Stream.of(new AssetModel(TestConfiguration.assetId, null)).collect(Collectors.toList())).build()).collect(Collectors.toList())).build();
		return UserAccountAssignmentRequest.builder().userAccounts(Arrays.asList(uaAssetRoles)).build();
	}

	public static ActionValidationResponse getActionValidationResponse() {
		return ActionValidationResponse.builder().associations(new UserAccountAssociations(Stream.generate(UUID::randomUUID).limit(2).collect(Collectors.toList()), Arrays.asList("asset_id_1", "asset_id_2"))).build();
	}

	public static ISuperUser getSuperUser() {
		return new SuperUserModel();
	}

	public static SuperUserEntity getSuperUserEntity() {
		return new SuperUserEntity("john@doe.com");
	}

	public static ActionValidationRequest getActionValidationRequest() {
		return ActionValidationRequest.builder().method("POST").actions(Arrays.asList("INTERNAL_USER", "EXTERNAL_USER")).build();
	}

	public static com.digitalrealty.gapi.user.model.UserAccountAsset getUserAccountAsset() {
		return new com.digitalrealty.gapi.user.model.UserAccountAsset(assetId, null, userAccountId);
	}

	public static UserAccountAsset getIUserAccountAsset() {
		return new UserAccountAsset();
	}

	public static UserAccountAssetEntity getUserAccountAssetEntity() {
		return new UserAccountAssetEntity(assetId, "SitePath", TestConfiguration.getUserAccountRoleAssetsEntity());
	}

	public static UserAccount getUserAccount() {
		UserAccount userAccount = new UserAccount(accountId, userId, UserAccountStatus.ACTIVE, ApprovalStatus.APPROVED, true, false, Instant.parse("2022-02-16T10:47:08.494244100Z"), new HashSet<com.digitalrealty.gapi.user.model.UserAccountRoleAssets>());
		userAccount.setId(userAccountId);
		return userAccount;
	}

	public static List<UserAccount> getUserAccountList() {
		List<UserAccount> userAccountList = new ArrayList<>();
		UserAccount userAccount = new UserAccount(accountId, userId, UserAccountStatus.ACTIVE, ApprovalStatus.APPROVED, true, false, Instant.parse("2022-02-16T10:47:08.494244100Z"), null);
		userAccount.setId(userAccountId);
		userAccountList.add(userAccount);
		return userAccountList;
	}

	public static List<UserAccountEntity> getUserAccountEntityList() {
		List<UserAccountEntity> userAccountList = new ArrayList<>();
		userAccountList.add(getUserAccountEntity());
		return userAccountList;
	}

	public static UserAccount getUserAccountData() {
		UserAccount userAccount = new UserAccount(accountId, userId, UserAccountStatus.ACTIVE, ApprovalStatus.APPROVED, true, false, Instant.parse("2022-02-16T10:47:08.494244100Z"), new HashSet<com.digitalrealty.gapi.user.model.UserAccountRoleAssets>());
		userAccount.setUserId(userId);
		userAccount.setId(userAccountId);
		return userAccount;
	}

	public static UserAccountEntity getUserAccountEntity() {
		return new UserAccountEntity(accountId, TestConfiguration.getUserEntity(), UserAccountStatus.ACTIVE, ApprovalStatus.APPROVED, true, false, Instant.parse("2022-02-16T10:47:08.494244100Z"), Stream.of(getUserAccountRoleAssetsEntity()).collect(Collectors.toSet()));
	}

	public static com.digitalrealty.gapi.user.model.UserAccountRole getUserAccountRole() {
		return new com.digitalrealty.gapi.user.model.UserAccountRole(roleId, userAccountId);
	}

	public static UserAccountRole getIUserAccountRole() {
		return new UserAccountRole();
	}

	public static UserAccountRoleEntity getUserAccountRoleEntity() {
		return new UserAccountRoleEntity(roleId, TestConfiguration.getUserAccountRoleAssetsEntity());
	}

	public static RoleCheckPermissionsRequest getRoleCheckPermissionsRequest() {
		return RoleCheckPermissionsRequest.builder().action(Arrays.asList("INTERNAL_USER", "EXTERNAL_USER")).method("POST").build();
	}

	public static UserAccountRoleAssetsEntity getUserAccountRoleAssetsEntity() {
		return new UserAccountRoleAssetsEntity();
	}

	public static MaintainUserMessage getMaintainUserMessageForCreateJms() {
		return new MaintainUserMessage(userId, UserRequestType.CREATED);
	}

	public static MaintainUserMessage getMaintainUserMessageForUpdateJms() {
		return new MaintainUserMessage(userId, UserRequestType.UPDATED);
	}

	public static UserEntity getUserEntityForAssignment() {
		UserAccountEntity uae = TestConfiguration.getUserAccountEntity();

		UserAccountRoleAssetsEntity roleAssets = new UserAccountRoleAssetsEntity();
		roleAssets.setUserAccountAssets(Stream.of(getUserAccountAssetEntity()).collect(Collectors.toSet()));
		roleAssets.setUserAccountRole(getUserAccountRoleEntity());

		uae.setUserAccountRoleAssets(Stream.of(roleAssets).collect(Collectors.toSet()));

		UserEntity uEntity = TestConfiguration.getUserEntity();
		uEntity.setUserAccounts(Stream.of(uae).collect(Collectors.toSet()));
		return uEntity;
	}

	public static SNowUserAndCompanyAssets getSNowUserAndCompanyAssets() {
		return SNowUserAndCompanyAssets.builder().result(Stream.of(UserAndCompanyAssets.builder().sys_created_by("dgloversa").sys_created_on("2017-09-20 16:03:54")
				.sys_id("061ac5ce13558380afc331f18144b077").sys_tags("test").build()).collect(Collectors.toList())).build();
	}

	public static SNowInsertUser getSNowInsertUpdateUserResponse() {
		return SNowInsertUser.builder().result(InsertUser.builder().sys_updated_by("test").sys_updated_on("2017-09-20 16:03:54").sys_id("1232").sys_created_by("test").sys_created_on("2017-09-20 16:03:54").build()).build();
	}

	public static SNowValidateUserExists getSNowValidateUserExists() {
		return SNowValidateUserExists.builder().result(Stream.of(ValidateUserExists.builder().sys_created_by("dgloversa").sys_created_on("2017-09-20 16:03:54")
				.sys_id("061ac5ce13558380afc331f18144b077").sys_tags("test").build()).collect(Collectors.toList())).build();
	}

	public static SNowUserSysIdByEmail getSNowUserSysIdByEmail() {
		return SNowUserSysIdByEmail.builder().result(Stream.of(UserSysIdByEmail.builder().sys_id("test").email("phantomtest@gmail.com").first_name("test").last_name("test").build()).collect(Collectors.toList())).build();
	}

	public static UserAccountAssociation getIUserAccountAssociation() {
		return new UserAccountAssociation();
	}

	// ********************************************************************************
	public static String asJsonString(final Object obj) {
		try {
			return userObjectMapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static class SuperUserModel implements ISuperUser {

		@Override
		public String getEmail() {
			return "john@doe.com";
		}
	}

	public static class UserAccountAssociation implements IUserAccountAssociation {
		public UserAccountAssociation() {
		}

		@Override
		public UUID getId() {
			return UUID.randomUUID();
		}

		@Override
		public String getCreatedBy() {
			return "";
		}

		@Override
		public Instant getCreatedDate() {
			return null;
		}

		@Override
		public String getLastModifiedBy() {
			return "";
		}

		@Override
		public Instant getLastModifiedDate() {
			return null;
		}

		@Override
		public Integer getVersion() {
			return 1;
		}

		@Override
		public UUID getRoleId() {
			return TestConfiguration.roleId;
		}

		@Override
		public String getAssetId() {
			return TestConfiguration.assetId;
		}

		@Override
		public String getAccountId() {
			return TestConfiguration.accountId;
		}

	}

	public static class UserAccountAsset implements IUserAccountAsset {

		public UserAccountAsset() {
		}

		@Override
		public UUID getId() {
			return UUID.randomUUID();
		}

		@Override
		public String getCreatedBy() {
			return "";
		}

		@Override
		public Instant getCreatedDate() {
			return null;
		}

		@Override
		public String getLastModifiedBy() {
			return "";
		}

		@Override
		public Instant getLastModifiedDate() {
			return null;
		}

		@Override
		public Integer getVersion() {
			return 1;
		}

		@Override
		public String getAssetId() {
			return TestConfiguration.assetId;
		}

		@Override
		public UUID getUserAccountRoleAssetsId() {
			return TestConfiguration.UserAccountRoleAssetsId;
		}

		@Override
		public String getSitePath() {
			return null;
		}
	}

	public static class UserAccountRole implements IUserAccountRole {

		public UserAccountRole() {
		}

		@Override
		public UUID getId() {
			return UUID.randomUUID();
		}

		@Override
		public String getCreatedBy() {
			return "";
		}

		@Override
		public Instant getCreatedDate() {
			return null;
		}

		@Override
		public String getLastModifiedBy() {
			return "";
		}

		@Override
		public Instant getLastModifiedDate() {
			return null;
		}

		@Override
		public Integer getVersion() {
			return 1;
		}

		@Override
		public UUID getRoleId() {
			return TestConfiguration.roleId;
		}

		@Override
		public UUID getUserAccountRoleAssetsId() {
			return TestConfiguration.UserAccountRoleAssetsId;
		}
	}

}