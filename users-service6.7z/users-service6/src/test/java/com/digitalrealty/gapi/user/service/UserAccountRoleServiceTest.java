package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.jboss.logging.MDC;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.common.context.ContextFields;
import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;
import com.digitalrealty.gapi.user.exception.UserErrorCode;
import com.digitalrealty.gapi.user.mapper.UserAccountRoleMapper;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountRoleResponse;

@ExtendWith(MockitoExtension.class)
public class UserAccountRoleServiceTest {

	@Mock
	UserAccountRoleMapper userAccountRoleMapper;

	@Mock
	UserDBService userDBService;

	@Mock
	SuperUserDBService superUserDBService;

	@Mock
	UserAccountDBService userAccountDBService;

	@Mock
	UserAccountRoleDBService userAccountRoleDBService;

	@Mock
	EncryptionService encryptionService;

	@InjectMocks
	UserAccountRoleService userAccountRoleService;

	@Test
	public void validateUserRoleTest() {
		when(userAccountRoleDBService.findUserAccountIdsByRoleId(TestConfiguration.roleId)).thenReturn(Stream.of(TestConfiguration.roleId).collect(Collectors.toList()));
		when(userAccountDBService.findByIdsAndStatus(Stream.of(TestConfiguration.roleId).collect(Collectors.toList()), UserAccountStatus.ACTIVE)).thenReturn(Stream.of(TestConfiguration.getUserAccount()).collect(Collectors.toList()));

		CommonException exception = Assertions.assertThrows(CommonException.class, () -> {
			userAccountRoleService.validateUserRole(TestConfiguration.roleId);
		});

		assertThat(exception.getErrorCode().getName()).isEqualTo(UserErrorCode.ROLE_ACTIVE.getName());
		verify(userAccountDBService, times(1)).findByIdsAndStatus(Stream.of(TestConfiguration.roleId).collect(Collectors.toList()), UserAccountStatus.ACTIVE);
	}

	@Test
	public void getUserRolesTest() {
		MDC.put(ContextFields.LEGALENTITY, TestConfiguration.accountId.toString());

		when(encryptionService.encryptEmail(Mockito.anyString())).thenReturn(TestConfiguration.userEmail);
		when(userAccountDBService.findByUserEmailAndApprovalStatus(TestConfiguration.userEmail, ApprovalStatus.APPROVED)).thenReturn(Stream.of(TestConfiguration.getUserAccount()).collect(Collectors.toList()));
		when(userAccountRoleDBService.findIdsByUserAccountId(TestConfiguration.userAccountId)).thenReturn(Stream.of(TestConfiguration.roleId).collect(Collectors.toList()));

		UserAccountRoleResponse userAccountRoleResponse = userAccountRoleService.getUserRoles();

		assertThat(userAccountRoleResponse.getUserAccountRoles()).isNotNull();
		verify(userAccountRoleDBService, times(1)).findIdsByUserAccountId(TestConfiguration.userAccountId);
	}
}