package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import com.digitalrealty.gapi.common.context.ContextFields;
import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.configuration.NoPermissionConfig;
import com.digitalrealty.gapi.user.mapper.ActionMapper;
import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.RoleCheckPermissionsRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssociations;

@ExtendWith(MockitoExtension.class)
public class AuthorizationServiceTest {

	@Mock
	ActionMapper actionMapper;

	@Mock
	UserDBService userDBService;

	@Mock
	SuperUserDBService superUserDBService;

	@Mock
	UserAccountDBService userAccountDBService;

	@Mock
	UserAccountRoleDBService userAccountRoleDBService;

	@Mock
	UserAccountAssetDBService userAccountAssetDBService;

	@Mock
	EncryptionService encryptionService;

	@Mock
	PermissionsService permissionService;

	@Mock
	AccountService accountService;

	@InjectMocks
	AuthorizationService authorizationService;

	@Mock
	NoPermissionConfig noPermissionConfig;

	@Test
	public void isAuthorizedTest() {
		MDC.put(ContextFields.LEGALENTITY, TestConfiguration.accountId.toString());

		ActionValidationRequest actionValidationRequest = ActionValidationRequest.builder().method("POST").actions(TestConfiguration.actions).build();
		when(encryptionService.encryptEmail(any(String.class))).thenReturn(TestConfiguration.superEmail);
		when(userDBService.findByEmail(TestConfiguration.superEmail)).thenReturn(TestConfiguration.getUser());
		when(userAccountDBService.findByUserId(TestConfiguration.getUser().getId())).thenReturn(Stream.of(TestConfiguration.getUserAccount()).collect(Collectors.toList()));
		when(accountService.checkAccountActive(TestConfiguration.accountId)).thenReturn(true);
		when(userAccountRoleDBService.findByUserAccountId(TestConfiguration.getUserAccount().getId())).thenReturn(Stream.of(TestConfiguration.getIUserAccountRole()).collect(Collectors.toList()));
		when(actionMapper.mapUserToActionValidationResponse(any(Boolean.class), any(UUID.class), any(UserAccountAssociations.class))).thenReturn(ActionValidationResponse.builder().build());
		when(noPermissionConfig.getName()).thenReturn("No permissions needed");
		ActionValidationResponse actionValidationResponse = authorizationService.isAuthorized(actionValidationRequest);

		assertThat(Objects.isNull(actionValidationResponse)).isEqualTo(false);
		verify(permissionService, times(1)).isAuthorized(any(RoleCheckPermissionsRequest.class));
	}
}
