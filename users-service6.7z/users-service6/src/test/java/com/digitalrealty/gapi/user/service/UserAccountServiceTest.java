package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.digitalrealty.gapi.messaging.email.SendEmailMessage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.common.exceptions.CommonException;
import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.enums.ApprovalStatus;
import com.digitalrealty.gapi.user.exception.UserErrorCode;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.payloadmodel.RoleValidationRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountApprovalResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssignmentRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssociationsResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.ValidateLegalEntitiesRequest;

@ExtendWith(MockitoExtension.class)
public class UserAccountServiceTest {

	@Mock
	AuthorizationService authorizationService;

	@Mock
	AccountService accountService;

	@Mock
	PermissionsService permissionsService;

	@Mock
	AssetService assetService;

	@Mock
	UserAccountDBService userAccountDBService;

	@Mock
	UserAccountRoleService userAccountRoleService;

	@Mock
	UserAccountAssetDBService userAccountAssetDBService;

	@Mock
	UserDBService userDBService;

	@Mock
	EncryptionService encryptionService;

	@Mock
	JmsUserService jmsUserService;

	@Mock
	SendEmailMessage sendEmailMessage;

	@Mock
	EmailService emailService;

	@InjectMocks
	UserAccountService userAccountService;

	@SuppressWarnings("unchecked")
	@Test
	void manageAssignmentsTest() {
		when(userDBService.findById(TestConfiguration.userId)).thenReturn(TestConfiguration.getUser());
		when(userDBService.saveUserAssignments(any(UUID.class), any(Boolean.class), any(UserAccountAssignmentRequest.class), any(Map.class), any(Map.class))).thenReturn(TestConfiguration.getUser());


		userAccountService.manageAssignments(TestConfiguration.userId, false, TestConfiguration.getUserAccountAssignmentRequest());

		verify(permissionsService, times(1)).validateRoles(any(RoleValidationRequest.class));
		verify(assetService, times(1)).validateAssets(Mockito.anyList());
		verify(userDBService, times(1)).saveUserAssignments(any(UUID.class), any(Boolean.class), any(UserAccountAssignmentRequest.class), any(Map.class), any(Map.class));
	}

	@Test
	public void manageDefaultAccountTest() {
		when(encryptionService.encryptEmail(Mockito.anyString())).thenReturn(TestConfiguration.userEmail);
		when(userAccountDBService.findByUserEmailAndApprovalStatus(TestConfiguration.userEmail, ApprovalStatus.APPROVED)).thenReturn(TestConfiguration.getUserAccountList());
		userAccountService.manageDefaultAccount();
		verify(userAccountDBService, times(1)).manageDefaultAccount(TestConfiguration.getUserAccountList());
	}

	@Test
	void manageAssignmentsTestforNotFoundUser() {
		when(userDBService.findById(TestConfiguration.userId)).thenReturn(null);

		Exception ex = Assertions.assertThrows(CommonException.class, () -> {
			userAccountService.manageAssignments(TestConfiguration.userId, false, TestConfiguration.getUserAccountAssignmentRequest());
		});

		assertThat(ex.getMessage()).contains(UserErrorCode.USER_NOTFOUND.getErrorText());
	}

	@Test
	void updateUserAccountApprovalTest() {
		Map<UUID, ApprovalStatus> userAccounts = new HashMap<UUID, ApprovalStatus>() {
			private static final long serialVersionUID = 1L;
			{
				put(TestConfiguration.userAccountId, ApprovalStatus.APPROVED);
			}
		};

		when(encryptionService.encryptEmail(Mockito.anyString())).thenReturn(TestConfiguration.userEmail);
		when(userDBService.findByEmail(TestConfiguration.userEmail)).thenReturn(TestConfiguration.getUser());
		when(userAccountDBService.findByIdIn(Stream.of(TestConfiguration.userAccountId).collect(Collectors.toList()))).thenReturn(Stream.of(TestConfiguration.getUserAccountData()).collect(Collectors.toList()));

		when(userAccountDBService.saveAccountApprovals(userAccounts)).thenReturn(Stream.of(TestConfiguration.getUserAccount()).collect(Collectors.toList()));

		UserAccountApprovalResponse userAccountApprovalResponse = userAccountService.updateUserAccountApproval(TestConfiguration.getUserAccountApprovalRequest());

		assertThat(userAccountApprovalResponse.getUserAccounts().get(0)).isEqualTo(TestConfiguration.userAccountId);
		verify(userAccountDBService, times(1)).saveAccountApprovals(userAccounts);
	}

	@Test
	void getUserAssignmentsTest() {
		User targetUser = TestConfiguration.getUser();
		targetUser.setUserAccounts(Stream.of(TestConfiguration.getUserAccount()).collect(Collectors.toSet()));

		when(userDBService.findById(TestConfiguration.userId)).thenReturn(targetUser);
		when(accountService.validateLegalEntities(any(ValidateLegalEntitiesRequest.class))).thenReturn(TestConfiguration.getValidateLegalEntitiesResponse());

		List<UserAccountAssociationsResponse> userAccountAssetRoles = userAccountService.getUserAssignments(TestConfiguration.userId);

		assertThat(userAccountAssetRoles.get(0).getLegalEntityKey()).isEqualTo(TestConfiguration.accountId);
		verify(userDBService, times(1)).findById(TestConfiguration.userId);
	}
}
