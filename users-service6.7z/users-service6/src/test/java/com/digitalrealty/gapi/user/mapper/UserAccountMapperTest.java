package com.digitalrealty.gapi.user.mapper;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.entity.UserAccountEntity;
import com.digitalrealty.gapi.user.model.UserAccount;

@ExtendWith(MockitoExtension.class)
public class UserAccountMapperTest {

	@Mock
	MappingUtil mappingUtil;

	@InjectMocks
	UserAccountMapper userAccountMapper = Mappers.getMapper(UserAccountMapper.class);

	@Test
	public void mapUserAccountEntityToUserAccountTest() {
		UserAccount userAccount = userAccountMapper.map(TestConfiguration.getUserAccountEntity());
		assertThat(userAccount.getLegalEntityKey()).isEqualTo(TestConfiguration.getUserAccountEntity().getLegalEntityKey());
	}

	@Test
	public void mapUserAccountToUserAccountEntityTest() {
		when(mappingUtil.getUserByUserId(TestConfiguration.getUserAccount().getUserId())).thenReturn(TestConfiguration.getUserEntity());

		UserAccountEntity userAccountEntity = userAccountMapper.map(TestConfiguration.getUserAccount());

		assertThat(userAccountEntity.getLegalEntityKey()).isEqualTo(TestConfiguration.getUserAccount().getLegalEntityKey());
	}
}
