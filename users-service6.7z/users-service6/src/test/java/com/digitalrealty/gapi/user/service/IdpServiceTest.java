package com.digitalrealty.gapi.user.service;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.common.auth.service.IdpAuthService;
import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.configuration.IdpTokenConfig;
import com.digitalrealty.gapi.user.configuration.UserConfig;
import com.digitalrealty.gapi.user.mapper.UserMapper;

@ExtendWith(MockitoExtension.class)
public class IdpServiceTest {

	@Mock
	private WebClient webClient;

	@Mock
	WebClient.RequestBodyUriSpec requestBodyUriSpecMock;

	@Mock
	WebClient.RequestBodySpec requestBodySpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersSpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock;

	@Mock
	WebClient.ResponseSpec responseSpecMock;

	@Mock
	private UserMapper userMapper;

	@Mock
	private UserConfig userConfig;

	@Mock
	private IdpAuthService idpAuthService;

	@Mock
	private UserDBService userDBService;

	@Mock
	private IdpTokenConfig accessTokenConfig;

	@Mock
	private IdpServiceRetryable idpServiceRetryable;

	@InjectMocks
	private IdpService idpService;

	@Test
	public void createIdpUserTest() {
		when(userDBService.saveUsers(Mockito.anyList())).thenReturn(Stream.of(TestConfiguration.getUserWithCreatedStatus()).collect(Collectors.toList()));

		idpService.syncUsersToIdp(Stream.of(TestConfiguration.getUserWithCreatedStatus()).collect(Collectors.toList()));

		verify(userDBService, times(1)).saveUsers(Mockito.anyList());
	}

	@Test
	public void updateIdpUserTest() {
		when(userDBService.saveUsers(Mockito.anyList())).thenReturn(Stream.of(TestConfiguration.getUserWithActiveStatus()).collect(Collectors.toList()));

		idpService.syncUsersToIdp(Stream.of(TestConfiguration.getUserWithActiveStatus()).collect(Collectors.toList()));

		verify(userDBService, times(1)).saveUsers(Mockito.anyList());
	}

	@Test
	public void deleteIdpUserTest() {
		when(userDBService.saveUsers(Mockito.anyList())).thenReturn(Stream.of(TestConfiguration.getUserWithNotActiveStatus()).collect(Collectors.toList()));

		idpService.syncUsersToIdp(Stream.of(TestConfiguration.getUserWithNotActiveStatus()).collect(Collectors.toList()));

		verify(userDBService, times(1)).saveUsers(Mockito.anyList());
	}

}
