package com.digitalrealty.gapi.user.service;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.user.configuration.UserConfig;

@ExtendWith(MockitoExtension.class)
public class PermissionsServiceTest {

	@Mock
	WebClient webClient;

	@Mock
	UserConfig userConfig;

	@InjectMocks
	PermissionsService permissionsService;
}
