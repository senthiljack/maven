package com.digitalrealty.gapi.user.mapper;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.model.User;

@ExtendWith(MockitoExtension.class)
public class UserMapperTest {

	@InjectMocks
	UserMapper userMapper = Mappers.getMapper(UserMapper.class);

	@Test
	public void mapUserEntityToUserTest() {
		User user = userMapper.map(TestConfiguration.getUserEntity());
		assertThat(user.getFirstName()).isEqualTo(TestConfiguration.getUserEntity().getFirstName());
	}

	@Test
	public void mapUserToUserEntityTest() {
		UserEntity userEntity = userMapper.map(TestConfiguration.getUser());
		assertThat(userEntity.getFirstName()).isEqualTo(TestConfiguration.getUser().getFirstName());
	}
}
