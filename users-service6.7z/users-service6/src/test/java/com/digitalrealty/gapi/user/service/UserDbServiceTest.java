package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.entity.UserEntity;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;
import com.digitalrealty.gapi.user.enums.UserStatus;
import com.digitalrealty.gapi.user.mapper.UserMapper;
import com.digitalrealty.gapi.user.model.User;
import com.digitalrealty.gapi.user.model.payloadmodel.ValidateLegalEntitiesRequest;
import com.digitalrealty.gapi.user.repository.UserRepository;

@ExtendWith(MockitoExtension.class)
public class UserDbServiceTest {

	@Mock
	AccountService accountService;

	@Mock
	UserRepository userRepository;

	@Mock
	UserMapper userMapper;

	@InjectMocks
	UserDBService userDBService;

	@Test
	public void updateExecutionIdTest() {
		doNothing().when(userRepository).updateExecutionId(anyString(), anyInt());
		userDBService.updateExecutionId(anyString(), anyInt());
		verify(userRepository, times(1)).updateExecutionId(anyString(), anyInt());
	}

	@Test
	public void findByExecutionIdTest() {
		when(userRepository.findByExecutionId(anyString())).thenReturn(TestConfiguration.getUserEntityList());
		when(userMapper.map(TestConfiguration.getUserEntity())).thenReturn(TestConfiguration.getUser());
		userDBService.findByExecutionId(anyString());
		verify(userRepository, times(1)).findByExecutionId(anyString());
	}

	@Test
	public void updateExecutionIdAsNullTest() {
		doNothing().when(userRepository).updateExecutionIdAsNull(anyString());
		userDBService.updateExecutionIdAsNull(anyString());
		verify(userRepository, times(1)).updateExecutionIdAsNull(anyString());
	}

	@Test
	public void resetExecutionIdsTest() {
		doNothing().when(userRepository).resetExecutionIds(1L);
		userDBService.resetExecutionIds(1L);
		verify(userRepository, times(1)).resetExecutionIds(1L);
	}

	@Test
	public void createUserTest() {
		when(userMapper.map(TestConfiguration.getCreateUserRequest())).thenReturn(TestConfiguration.getUserEntity());
		when(userRepository.save(any())).thenReturn(TestConfiguration.getUserEntity());
		when(userMapper.map(TestConfiguration.getUserEntity())).thenReturn(TestConfiguration.getUser());

		User user = userDBService.createUser(TestConfiguration.getCreateUserRequest());

		assertThat(user.getFirstName()).isEqualTo(TestConfiguration.getCreateUserRequest().getFirstName());
		verify(userRepository, times(1)).save(any());
	}

	@Test
	public void updateUserTest() {
		when(userRepository.findById(TestConfiguration.getUser().getId())).thenReturn(Optional.of(TestConfiguration.getUserEntity()));
		when(userRepository.save(any())).thenReturn(TestConfiguration.getUserEntity());
		when(userMapper.map(TestConfiguration.getUserEntity())).thenReturn(TestConfiguration.getUser());

		User user = userDBService.updateUser(TestConfiguration.getUser().getId(), TestConfiguration.getUserUpdateRequest());

		assertThat(user.getFirstName()).isEqualTo(TestConfiguration.getUserUpdateRequest().getFirstName());
		verify(userRepository, times(1)).save(TestConfiguration.getUserEntity());
	}

	@Test
	public void saveUserTest() {
		when(userMapper.map(TestConfiguration.getUser())).thenReturn(TestConfiguration.getUserEntity());
		when(userRepository.save(TestConfiguration.getUserEntity())).thenReturn(TestConfiguration.getUserEntity());
		when(userMapper.map(TestConfiguration.getUserEntity())).thenReturn(TestConfiguration.getUser());

		User user = userDBService.saveUser(TestConfiguration.getUser());

		assertThat(user.getFirstName()).isEqualTo(TestConfiguration.getCreateUserRequest().getFirstName());
		verify(userRepository, times(1)).save(TestConfiguration.getUserEntity());
	}

	@Test
	public void findByEmailTest() {
		when(userRepository.findByEmail(TestConfiguration.userEmail)).thenReturn(TestConfiguration.getUserEntity());
		when(userMapper.map(TestConfiguration.getUserEntity())).thenReturn(TestConfiguration.getUser());

		User user = userDBService.findByEmail(TestConfiguration.userEmail);

		assertThat(user.getFirstName()).isEqualTo(TestConfiguration.getUser().getFirstName());
		verify(userRepository, times(1)).findByEmail(TestConfiguration.userEmail);
	}

	@Test
	public void findByIdTest() {
		when(userRepository.findById(TestConfiguration.getUser().getId())).thenReturn(Optional.of(TestConfiguration.getUserEntity()));
		when(userMapper.map(TestConfiguration.getUserEntity())).thenReturn(TestConfiguration.getUser());

		User user = userDBService.findById(TestConfiguration.getUser().getId());

		assertThat(user.getFirstName()).isEqualTo(TestConfiguration.getCreateUserRequest().getFirstName());
		verify(userRepository, times(1)).findById(TestConfiguration.getUser().getId());
	}

	@Test
	public void findByIdInTest() {
		List<UUID> userIdList = Arrays.asList(TestConfiguration.getUser().getId());
		Pageable page = PageRequest.of(0, 10, Sort.by(Sort.Direction.ASC, "id"));

		when(userRepository.findByIdIn(userIdList, page)).thenReturn(new PageImpl<UserEntity>(Stream.of(TestConfiguration.getUserEntity()).collect(Collectors.toList())));
		when(userMapper.map(TestConfiguration.getUserEntity())).thenReturn(TestConfiguration.getUser());

		List<User> userList = userDBService.findByIdIn(userIdList, page);

		assertThat(userList.get(0).getFirstName()).isEqualTo(TestConfiguration.getUserEntity().getFirstName());
		verify(userRepository, times(1)).findByIdIn(userIdList, page);
	}

	@Test
	public void findByStatusTest() {
		when(userRepository.findByStatus(UserStatus.ACTIVE)).thenReturn(Stream.of(TestConfiguration.getUserEntity()).collect(Collectors.toList()));
		when(userMapper.map(TestConfiguration.getUserEntity())).thenReturn(TestConfiguration.getUser());

		List<User> user = userDBService.findByStatus(UserStatus.ACTIVE);

		assertThat(user.get(0).getFirstName()).isEqualTo(TestConfiguration.getCreateUserRequest().getFirstName());
		verify(userRepository, times(1)).findByStatus(UserStatus.ACTIVE);
	}

	@Test
	public void saveTermsAndConditions() {
		when(userRepository.findByEmail(TestConfiguration.userEmail)).thenReturn(TestConfiguration.getUserEntity());
		when(userRepository.save(any(UserEntity.class))).thenReturn(TestConfiguration.getUserEntity());
		when(userMapper.map(TestConfiguration.getUserEntity())).thenReturn(TestConfiguration.getUser());

		User user = userDBService.saveTermsAndConditions(TestConfiguration.userEmail, TestConfiguration.getTermsConditionsRequest());

		assertThat(user.getFirstName()).isEqualTo(TestConfiguration.getCreateUserRequest().getFirstName());
		verify(userRepository, times(1)).save(any(UserEntity.class));
	}

	@Test
	void saveUserAssignmentsTest() {
		UserEntity uEntity = TestConfiguration.getUserEntityForAssignment();
		when(accountService.validateLegalEntities(any(ValidateLegalEntitiesRequest.class))).thenReturn(TestConfiguration.getValidateLegalEntitiesResponse());
		when(userRepository.findById(TestConfiguration.getUser().getId())).thenReturn(Optional.of(uEntity));
		when(userRepository.save(any(UserEntity.class))).thenReturn(TestConfiguration.getUserEntity());
		when(userMapper.map(any(UserEntity.class))).thenReturn(TestConfiguration.getUser());

		User user = userDBService.saveUserAssignments(TestConfiguration.getUserEntity().getId(), false, TestConfiguration.getUserAccountAssignmentRequest(),
				Collections.singletonMap(TestConfiguration.accountId, TestConfiguration.getUserAccountRoleResponse().getUserAccountRoles()),
				Collections.singletonMap(TestConfiguration.accountId, TestConfiguration.getUserAccountAssetResponse().getUserAccountAssets()));

		assertThat(user.getFirstName()).isEqualTo(uEntity.getFirstName());
		verify(userRepository, times(1)).save(any(UserEntity.class));
	}
	
	@Test
	void test() {
		userDBService.getAllUsersWithDeletedAccountsForLE(Collections.emptyList());
		verify(userRepository, times(1)).findByUserAccountsLegalEntityKeyInAndUserAccountsStatus(Collections.emptyList(), UserAccountStatus.DELETED);
	}

}