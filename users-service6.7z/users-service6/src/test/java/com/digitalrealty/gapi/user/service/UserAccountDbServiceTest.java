package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.enums.UserAccountStatus;
import com.digitalrealty.gapi.user.mapper.UserAccountMapper;
import com.digitalrealty.gapi.user.model.UserAccount;
import com.digitalrealty.gapi.user.repository.UserAccountRepository;

@ExtendWith(MockitoExtension.class)
public class UserAccountDbServiceTest {

	@Mock
	UserAccountRepository userAccountRepository;

	@Mock
	UserAccountMapper userAccountMapper;

	@InjectMocks
	UserAccountDBService userAccountDbService;

	@Test
	public void findByAccountIdAndUserIdTest() {
		when(userAccountRepository.findByLegalEntityKeyAndUserId(TestConfiguration.getUserAccount().getLegalEntityKey(), TestConfiguration.getUserAccount().getUserId())).thenReturn(TestConfiguration.getUserAccountEntity());
		when(userAccountMapper.map(TestConfiguration.getUserAccountEntity())).thenReturn(TestConfiguration.getUserAccount());

		UserAccount userAccount = userAccountDbService.findByAccountIdAndUserId(TestConfiguration.getUserAccount().getLegalEntityKey(), TestConfiguration.getUserAccount().getUserId());

		assertThat(userAccount.getId()).isEqualTo(TestConfiguration.getUserAccount().getId());
		verify(userAccountRepository, times(1)).findByLegalEntityKeyAndUserId(TestConfiguration.getUserAccount().getLegalEntityKey(), TestConfiguration.getUserAccount().getUserId());
	}

	@Test
	public void findByAccountIdTest() {
		when(userAccountRepository.findByLegalEntityKey(TestConfiguration.getUserAccount().getLegalEntityKey())).thenReturn(Stream.of(TestConfiguration.getUserAccountEntity()).collect(Collectors.toList()));
		when(userAccountMapper.map(TestConfiguration.getUserAccountEntity())).thenReturn(TestConfiguration.getUserAccount());

		List<UserAccount> userAccountList = userAccountDbService.findByAccountId(TestConfiguration.getUserAccount().getLegalEntityKey());

		assertThat(userAccountList.get(0).getUserId()).isEqualTo(TestConfiguration.getUserAccountEntity().getUser().getId());
		verify(userAccountRepository, times(1)).findByLegalEntityKey(TestConfiguration.getUserAccount().getLegalEntityKey());
	}

	@Test
	public void findByIdsAndStatus() {
		List<UUID> userAccountIds = Stream.of(TestConfiguration.userAccountId).collect(Collectors.toList());
		when(userAccountRepository.findByIdInAndStatus(userAccountIds, UserAccountStatus.ACTIVE)).thenReturn(Stream.of(TestConfiguration.getUserAccountEntity()).collect(Collectors.toList()));
		when(userAccountMapper.map(TestConfiguration.getUserAccountEntity())).thenReturn(TestConfiguration.getUserAccount());

		List<UserAccount> userAccountList = userAccountDbService.findByIdsAndStatus(userAccountIds, UserAccountStatus.ACTIVE);

		assertThat(userAccountList.get(0).getUserId()).isEqualTo(TestConfiguration.getUserAccountEntity().getUser().getId());
		verify(userAccountRepository, times(1)).findByIdInAndStatus(userAccountIds, UserAccountStatus.ACTIVE);
	}

	@Test
	public void findByUserIdTest() {
		when(userAccountRepository.findByUserId(TestConfiguration.getUserAccount().getUserId())).thenReturn(Stream.of(TestConfiguration.getUserAccountEntity()).collect(Collectors.toList()));
		when(userAccountMapper.map(TestConfiguration.getUserAccountEntity())).thenReturn(TestConfiguration.getUserAccount());

		List<UserAccount> userAccountList = userAccountDbService.findByUserId(TestConfiguration.getUserAccount().getUserId());

		assertThat(userAccountList.get(0).getLegalEntityKey()).isEqualTo(TestConfiguration.getUserAccount().getLegalEntityKey());
		verify(userAccountRepository, times(1)).findByUserId(TestConfiguration.getUserAccount().getUserId());
	}
}