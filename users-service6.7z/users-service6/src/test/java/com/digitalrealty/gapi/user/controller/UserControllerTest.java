package com.digitalrealty.gapi.user.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.configuration.ActionsConfig;
import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationRequest;
import com.digitalrealty.gapi.user.service.AccountService;
import com.digitalrealty.gapi.user.service.AuthorizationService;
import com.digitalrealty.gapi.user.service.UserAccountAssetService;
import com.digitalrealty.gapi.user.service.UserAccountRoleService;
import com.digitalrealty.gapi.user.service.UserAccountService;
import com.digitalrealty.gapi.user.service.UserService;

@ExtendWith(MockitoExtension.class)
class UserControllerTest {

	@Mock
	AuthorizationService authorizationService;

	@Mock
	AccountService accountService;

	@Mock
	UserAccountService userAccountService;

	@Mock
	UserService userService;

	@Mock
	UserAccountRoleService userAccountRoleService;

	@Mock
	UserAccountAssetService userAccountAssetService;

	@InjectMocks
	UserController userController;

	@Mock
	ActionsConfig actionsConfig;

	@Test
	void createUserTest() throws Exception {
		when(authorizationService.isAuthorized(any(ActionValidationRequest.class))).thenReturn(TestConfiguration.getActionValidationResponse());

		userController.createUser(TestConfiguration.getCreateUserRequest());

		verify(userService, times(1)).createUser(TestConfiguration.getCreateUserRequest());
	}

	@Test
	void updateUserTest() throws Exception {
		when(authorizationService.isAuthorized(any(ActionValidationRequest.class))).thenReturn(TestConfiguration.getActionValidationResponse());

		userController.updateUser(TestConfiguration.userId, TestConfiguration.getUserUpdateRequest());

		verify(userService, times(1)).updateUser(TestConfiguration.userId, TestConfiguration.getUserUpdateRequest());
	}

	@Test
	void getUserProfileTest() throws Exception {
		when(authorizationService.isAuthorized(any(ActionValidationRequest.class))).thenReturn(TestConfiguration.getActionValidationResponse());

		userController.getUserProfile(TestConfiguration.userId);

		verify(userService, times(1)).getUser(TestConfiguration.userId);
	}

	@Test
	void getUsersInAccountTest() throws Exception {
		when(authorizationService.isAuthorized(any(ActionValidationRequest.class))).thenReturn(TestConfiguration.getActionValidationResponse());

		userController.getUsersInAccount( "", 0, 10);

		verify(userService, times(1)).getUsers(Mockito.any(Pageable.class));
	}

	@Test
	void getUserAssetsTest() throws Exception {
		userController.getUserAssets();

		verify(userAccountAssetService, times(1)).getUserAssets();
	}

	@Test
	void getUserRolesTest() throws Exception {
		userController.getUserRoles();

		verify(userAccountRoleService, times(1)).getUserRoles();
	}

	@Test
	void manageDefaultAccountTest() throws Exception {
		userController.manageDefaultAccount();
		verify(userAccountService, times(1)).manageDefaultAccount();
	}

	@Test
	void updateUserAccountStatusTest() throws Exception {
		userController.updateUserAccountStatus(TestConfiguration.userId, TestConfiguration.getUserAccountStatusRequest());

		verify(userAccountService, times(1)).updateUserAccountStatus(TestConfiguration.userId, TestConfiguration.getUserAccountStatusRequest());
	}

	@Test
	void updateUserAccountApprovalTest() throws Exception {
		userController.updateUserAccountApproval(TestConfiguration.getUserAccountApprovalRequest());

		verify(userAccountService, times(1)).updateUserAccountApproval(TestConfiguration.getUserAccountApprovalRequest());
	}

	@Test
	void getAssignmentsTest() throws Exception {
		userController.getUserAssignments(TestConfiguration.userId);

		verify(userAccountService, times(1)).getUserAssignments(TestConfiguration.userId);
	}

	@Test
	void manageAssignmentsTest() throws Exception {
		when(authorizationService.isAuthorized(any(ActionValidationRequest.class))).thenReturn(TestConfiguration.getActionValidationResponse());

		userController.manageAssignments(TestConfiguration.userId, TestConfiguration.getUserAccountAssignmentRequest());

		verify(userAccountService, times(1)).manageAssignments(TestConfiguration.userId, true, TestConfiguration.getUserAccountAssignmentRequest());
	}

}
