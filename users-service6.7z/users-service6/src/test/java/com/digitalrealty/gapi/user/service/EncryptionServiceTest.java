package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class EncryptionServiceTest {

	@InjectMocks
	EncryptionService encryptionService;

	@Test
	public void encryptEmailTest() {
		String email = encryptionService.encryptEmail("john@doe.com");

		assertThat(email).isEqualTo("john@doe.com");
	}
}
