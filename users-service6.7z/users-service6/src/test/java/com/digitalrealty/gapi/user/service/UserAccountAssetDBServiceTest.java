package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.mapper.UserAccountAssetMapper;
import com.digitalrealty.gapi.user.model.IUserAccountAsset;
import com.digitalrealty.gapi.user.repository.UserAccountAssetRepository;

@ExtendWith(MockitoExtension.class)
public class UserAccountAssetDBServiceTest {

	@Mock
	UserAccountAssetRepository userAccountAssetRepository;

	@Mock
	UserAccountAssetMapper userAccountAssetMapper;

	@InjectMocks
	UserAccountAssetDBService userAccountAssetDBService;

	@Test
	public void findByUserAccountIdTest() {
		when(userAccountAssetRepository.findByUserAccountId(TestConfiguration.getUserAccount().getId())).thenReturn(Stream.of(TestConfiguration.getIUserAccountAsset()).collect(Collectors.toList()));

		List<IUserAccountAsset> userAccountAssetList = userAccountAssetDBService.findByUserAccountId(TestConfiguration.getUserAccount().getId());

		assertThat(userAccountAssetList.get(0).getAssetId()).isEqualTo(TestConfiguration.getUserAccountAssetEntity().getAssetId());
		verify(userAccountAssetRepository, times(1)).findByUserAccountId(TestConfiguration.getUserAccount().getId());
	}

}