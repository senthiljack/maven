package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.repository.SuperUserRepository;

@ExtendWith(MockitoExtension.class)
public class SuperUserDBServiceTest {

	@Mock
	SuperUserRepository superUserRepository;

	@InjectMocks
	SuperUserDBService superUserDBService;

	@Test
	public void findByEmailTest() {
		when(superUserRepository.findByEmail(TestConfiguration.getSuperUserEntity().getEmail())).thenReturn(TestConfiguration.getSuperUser().getEmail());

		String superUser = superUserDBService.findByEmail(TestConfiguration.getSuperUserEntity().getEmail());

		assertThat(superUser).isEqualTo(TestConfiguration.getSuperUserEntity().getEmail());
		verify(superUserRepository, times(1)).findByEmail(TestConfiguration.getSuperUserEntity().getEmail());
	}
}