package com.digitalrealty.gapi.user.mapper;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.entity.UserAccountAssetEntity;
import com.digitalrealty.gapi.user.model.UserAccountAsset;

@ExtendWith(MockitoExtension.class)
public class UserAccountAssetMapperTest {

	@Mock
	MappingUtil mappingUtil;

	@InjectMocks
	UserAccountAssetMapper userAccountAssetMapper = Mappers.getMapper(UserAccountAssetMapper.class);

	@Test
	public void mapUserAccountAssetEntityToUserAccountAssetTest() {
		UserAccountAsset userAccountAsset = userAccountAssetMapper.map(TestConfiguration.getUserAccountAssetEntity());
		assertThat(userAccountAsset.getAssetId()).isEqualTo(TestConfiguration.getUserAccountAssetEntity().getAssetId());
	}

	@Test
	public void mapUserAccountAssetToUserAccountAssetEntityTest() {
		UserAccountAssetEntity userAccountAssetEntity = userAccountAssetMapper.map(TestConfiguration.getUserAccountAsset());

		assertThat(userAccountAssetEntity.getAssetId()).isEqualTo(TestConfiguration.getUserAccountAsset().getAssetId());
	}
}
