package com.digitalrealty.gapi.user.mapper;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import java.util.Arrays;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationResponse;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssociations;

@ExtendWith(MockitoExtension.class)
public class ActionMapperTest {

	@InjectMocks
	ActionMapper actionMapper = Mappers.getMapper(ActionMapper.class);

	@Test
	public void mapUserToActionValidationResponseTest() {
		ActionValidationResponse actionValidationResponse = actionMapper.mapUserToActionValidationResponse(false, TestConfiguration.userId, new UserAccountAssociations(Stream.generate(UUID::randomUUID).limit(2).collect(Collectors.toList()), Arrays.asList("Asset_1", "Asset_2", "Asset_3")));
		assertThat(actionValidationResponse.getAssociations().getAccountRoleIds().size()).isEqualTo(2);
	}

}
