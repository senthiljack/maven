package com.digitalrealty.gapi.user.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.configuration.ActionsConfig;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountApprovalRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountAssignmentRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserAccountStatusRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserCreateRequest;
import com.digitalrealty.gapi.user.model.payloadmodel.UserUpdateRequest;
import com.digitalrealty.gapi.user.service.AccountService;
import com.digitalrealty.gapi.user.service.AuthorizationService;
import com.digitalrealty.gapi.user.service.UserAccountAssetService;
import com.digitalrealty.gapi.user.service.UserAccountRoleService;
import com.digitalrealty.gapi.user.service.UserAccountService;
import com.digitalrealty.gapi.user.service.UserService;

@ExtendWith(MockitoExtension.class)
class UserControllerMvcTest {
	MockMvc mockMvc;

	@Mock
	AuthorizationService authorizationService;

	@Mock
	AccountService accountService;

	@Mock
	UserService userService;

	@Mock
	UserAccountService userAccountService;

	@Mock
	UserAccountRoleService userAccountRoleService;

	@Mock
	UserAccountAssetService userAccountAssetService;

	@InjectMocks
	UserController userController;

	@Mock
	ActionsConfig actionsConfig;

	@BeforeEach
	void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
	}

	@Test
	void createUserTest() throws Exception {
		UserCreateRequest request = TestConfiguration.getCreateUserRequest();
		mockMvc.perform(MockMvcRequestBuilders.post("/users").content(TestConfiguration.asJsonString(request)).contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isCreated());
	}

	@Test
	void updateUserTest() throws Exception {
		UserUpdateRequest request = TestConfiguration.getUserUpdateRequest();
		mockMvc.perform(MockMvcRequestBuilders.put(String.format("/users/%s", TestConfiguration.userId)).content(TestConfiguration.asJsonString(request)).contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void getUserProfileTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(String.format("/users/%s", TestConfiguration.userId)).contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void getUsersInAccountTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/users/accounts")
				.queryParam("sort", "asc")
				.queryParam("page", "0")
				.queryParam("size", "10")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void getUserAssetsTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/users/assetIds").contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void getUserRolesTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/users/roleIds").contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void getUserAccountsTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/users/accountIds").contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void updateUserAccountStatusTest() throws Exception {
		UserAccountStatusRequest request = TestConfiguration.getUserAccountStatusRequest();
		mockMvc.perform(MockMvcRequestBuilders.put(String.format("/users/%s/user-account-status", TestConfiguration.userId)).content(TestConfiguration.asJsonString(request)).contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void updateUserAccountApprovalTest() throws Exception {
		UserAccountApprovalRequest request = TestConfiguration.getUserAccountApprovalRequest();
		mockMvc.perform(MockMvcRequestBuilders.put("/users/user-account-approvals").content(TestConfiguration.asJsonString(request)).contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void getAssignmentsTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(String.format("/users/%s/assignments", TestConfiguration.userId)).contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void manageAssignmentsTest() throws Exception {
		UserAccountAssignmentRequest request = TestConfiguration.getUserAccountAssignmentRequest();
		mockMvc.perform(MockMvcRequestBuilders.put(String.format("/users/%s/assignments", TestConfiguration.userId)).content(TestConfiguration.asJsonString(request)).contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk());
	}
}
