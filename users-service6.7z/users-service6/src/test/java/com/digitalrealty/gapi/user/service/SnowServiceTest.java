package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.function.Function;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.digitalrealty.gapi.common.auth.service.SnowAuthService;
import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.configuration.UserConfig;
import com.digitalrealty.gapi.user.mapper.UserMapper;
import com.digitalrealty.gapi.user.mapper.UserObjectMapper;
import com.digitalrealty.gapi.user.model.snow.SNowInsertUser;
import com.digitalrealty.gapi.user.model.snow.SNowInsertUserRequest;
import com.digitalrealty.gapi.user.model.snow.SNowUpdateUser;
import com.digitalrealty.gapi.user.model.snow.SNowUserAndCompanyAssets;
import com.digitalrealty.gapi.user.model.snow.SNowUserSysIdByEmail;
import com.digitalrealty.gapi.user.model.snow.SNowValidateUserExists;
import com.digitalrealty.gapi.user.model.snow.SnowCreateUserRequest;
import com.digitalrealty.gapi.user.model.snow.SnowCreateUserResponse;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class SnowServiceTest {

	@Mock
	private WebClient webClient;

	@Mock
	WebClient.RequestBodyUriSpec requestBodyUriSpecMock;

	@Mock
	WebClient.RequestBodySpec requestBodySpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersSpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersMock;

	@Mock
	WebClient.ResponseSpec responseSpecMock;

	@Mock
	private UserMapper userMapper;

	@Mock
	private UserConfig userConfig;

	@Mock
	private UserDBService userDBService;

	@Mock
	private SnowAuthService snowAuthService;

	@Mock
	UserObjectMapper userObjectMapper;

	@InjectMocks
	private SnowServiceRetryable snowServiceRetryable;

	@SuppressWarnings("unchecked")
	@Test
	public void createSnowUserTest() {
		when(userMapper.mapUserToSnowCreateUserRequest(TestConfiguration.getUserWithCreatedStatus())).thenReturn(TestConfiguration.getSnowCreateUserRequest());
		when(webClient.post()).thenReturn(requestBodyUriSpecMock);
		when(requestBodyUriSpecMock.uri(Mockito.anyString())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.contentType(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.accept(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.body(Mockito.any(), eq(SnowCreateUserRequest.class))).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
		when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(SnowCreateUserResponse.class)).thenReturn(Mono.just(TestConfiguration.getSnowCreateUserResponse()));

		snowServiceRetryable.createSnowUser(TestConfiguration.getUserWithCreatedStatus());
		verify(webClient, atLeastOnce()).post();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void updateSnowUserTest() {
		when(userMapper.mapUserToSnowCreateUserRequest(TestConfiguration.getUserWithActiveStatus())).thenReturn(TestConfiguration.getSnowCreateUserRequest());
		when(webClient.post()).thenReturn(requestBodyUriSpecMock);
		when(requestBodyUriSpecMock.uri(Mockito.any(Function.class))).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.contentType(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.accept(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.body(Mockito.any(), eq(SnowCreateUserRequest.class))).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
		when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(SnowCreateUserResponse.class)).thenReturn(Mono.just(TestConfiguration.getSnowCreateUserResponse()));

		snowServiceRetryable.updateSnowUser(TestConfiguration.getUserWithActiveStatus());
		verify(webClient, times(1)).post();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void deleteSnowUserTest() {
		when(webClient.delete()).thenReturn(requestHeadersUriSpecMock);
		when(requestHeadersUriSpecMock.uri(Mockito.any(Function.class))).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
		when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(Void.class)).thenReturn(Mono.empty());

		snowServiceRetryable.deleteSnowUser(TestConfiguration.getUserWithNotActiveStatus());
		verify(webClient, times(1)).delete();
	}

	@Test
	void getUserAndCompanyAssets() {

		when(userConfig.getSnowServiceURL()).thenReturn("http://test.com");
		when(userConfig.getUserAndCompanyAssetsPath()).thenReturn("testpath");
		TestConfiguration.getSNowUserAndCompanyAssets();

		when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
		when(requestHeadersUriSpecMock.uri(Mockito.anyString())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.headers(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.accept(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.retrieve()).thenReturn(responseSpecMock);
		when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(SNowUserAndCompanyAssets.class)).thenReturn(Mono.just(TestConfiguration.getSNowUserAndCompanyAssets()));

		SNowUserAndCompanyAssets response = snowServiceRetryable.getUserAndCompanyAssets("Testing");
		assertThat(response.getResult().get(0).getSys_created_by()).isEqualTo(TestConfiguration.getSNowUserAndCompanyAssets().getResult().get(0).getSys_created_by());
		assertThat(response.getResult().get(0).getSys_created_on()).isEqualTo(TestConfiguration.getSNowUserAndCompanyAssets().getResult().get(0).getSys_created_on());
		assertThat(response.getResult().get(0).getSys_id()).isEqualTo(TestConfiguration.getSNowUserAndCompanyAssets().getResult().get(0).getSys_id());
		assertThat(response.getResult().get(0).getSys_tags()).isEqualTo(TestConfiguration.getSNowUserAndCompanyAssets().getResult().get(0).getSys_tags());
	}

	@Test
	void insertUser() {

		when(userConfig.getSnowServiceURL()).thenReturn("http://test.com");
		SNowInsertUser sNowInsertUser = TestConfiguration.getSNowInsertUpdateUserResponse();

		when(webClient.post()).thenReturn(requestBodyUriSpecMock);
		when(requestBodyUriSpecMock.uri(Mockito.anyString())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.headers(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.accept(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.body(Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
		when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(SNowInsertUser.class)).thenReturn(Mono.just(sNowInsertUser));

		SNowInsertUser response = snowServiceRetryable.insertUser(new SNowInsertUserRequest());

		assertThat(response.getResult().getSys_updated_by()).isEqualTo(sNowInsertUser.getResult().getSys_updated_by());
		assertThat(response.getResult().getSys_updated_on()).isEqualTo(sNowInsertUser.getResult().getSys_updated_on());
		assertThat(response.getResult().getSys_created_by()).isEqualTo(sNowInsertUser.getResult().getSys_created_by());
		assertThat(response.getResult().getSys_created_on()).isEqualTo(sNowInsertUser.getResult().getSys_created_on());
		assertThat(response.getResult().getSys_id()).isEqualTo(sNowInsertUser.getResult().getSys_id());
	}

	@Test
	void updateUser() {

		when(userConfig.getSnowServiceURL()).thenReturn("http://test.com");
		when(userConfig.getUpdateUserPath()).thenReturn("/test/123");
		SNowInsertUser sNowInsertUser = TestConfiguration.getSNowInsertUpdateUserResponse();

		when(webClient.patch()).thenReturn(requestBodyUriSpecMock);
		when(requestBodyUriSpecMock.uri(Mockito.anyString())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.headers(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.accept(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.body(Mockito.any())).thenReturn(requestHeadersSpecMock);
		when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
		when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(SNowInsertUser.class)).thenReturn(Mono.just(sNowInsertUser));

		SNowUpdateUser sNowUpdateUser = new SNowUpdateUser();
		SNowInsertUser response = snowServiceRetryable.updateUser("test", sNowUpdateUser);
		assertThat(response.getResult().getSys_updated_by()).isEqualTo(sNowInsertUser.getResult().getSys_updated_by());
		assertThat(response.getResult().getSys_updated_on()).isEqualTo(sNowInsertUser.getResult().getSys_updated_on());
		assertThat(response.getResult().getSys_created_by()).isEqualTo(sNowInsertUser.getResult().getSys_created_by());
		assertThat(response.getResult().getSys_created_on()).isEqualTo(sNowInsertUser.getResult().getSys_created_on());
		assertThat(response.getResult().getSys_id()).isEqualTo(sNowInsertUser.getResult().getSys_id());
	}

	@Test
	void validateUserExists() {

		when(userConfig.getSnowServiceURL()).thenReturn("http://test.com");
		SNowValidateUserExists sNowValidateUserExists = TestConfiguration.getSNowValidateUserExists();

		when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
		when(requestHeadersUriSpecMock.uri(Mockito.anyString())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.headers(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.accept(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.retrieve()).thenReturn(responseSpecMock);
		when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(SNowValidateUserExists.class)).thenReturn(Mono.just(sNowValidateUserExists));

		SNowValidateUserExists response = snowServiceRetryable.validateUserExists("uCustomerRef", "uCmdbCiRef", "uContactRef", "uLocationRef");
		assertThat(response.getResult().get(0).getSys_created_by()).isEqualTo(sNowValidateUserExists.getResult().get(0).getSys_created_by());
		assertThat(response.getResult().get(0).getSys_created_on()).isEqualTo(sNowValidateUserExists.getResult().get(0).getSys_created_on());
		assertThat(response.getResult().get(0).getSys_id()).isEqualTo(sNowValidateUserExists.getResult().get(0).getSys_id());
		assertThat(response.getResult().get(0).getSys_tags()).isEqualTo(sNowValidateUserExists.getResult().get(0).getSys_tags());
	}

	@Test
	void getUserSysIdByEmail() {

		when(userConfig.getSnowServiceURL()).thenReturn("http://test.com");
		SNowUserSysIdByEmail sNowUserSysIdByEmail = TestConfiguration.getSNowUserSysIdByEmail();

		when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
		when(requestHeadersUriSpecMock.uri(Mockito.anyString())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.headers(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.accept(Mockito.any())).thenReturn(requestBodySpecMock);
		when(requestBodySpecMock.retrieve()).thenReturn(responseSpecMock);
		when(responseSpecMock.onStatus(Mockito.any(), Mockito.any())).thenReturn(responseSpecMock);
		when(responseSpecMock.bodyToMono(SNowUserSysIdByEmail.class)).thenReturn(Mono.just(sNowUserSysIdByEmail));

		SNowUserSysIdByEmail response = snowServiceRetryable.getUserSysIdByEmail("phantomtest@gmail.com");
		assertThat(response.getResult().get(0).getSys_id()).isEqualTo(sNowUserSysIdByEmail.getResult().get(0).getSys_id());
		assertThat(response.getResult().get(0).getEmail()).isEqualTo(sNowUserSysIdByEmail.getResult().get(0).getEmail());
		assertThat(response.getResult().get(0).getFirst_name()).isEqualTo(sNowUserSysIdByEmail.getResult().get(0).getFirst_name());
		assertThat(response.getResult().get(0).getLast_name()).isEqualTo(sNowUserSysIdByEmail.getResult().get(0).getLast_name());
	}

}
