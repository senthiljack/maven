package com.digitalrealty.gapi.user.controller;

import com.digitalrealty.gapi.common.context.ContextFields;
import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.model.payloadmodel.ActionValidationRequest;
import com.digitalrealty.gapi.user.service.AuthorizationService;
import com.digitalrealty.gapi.user.service.UserAccountRoleService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
public class ActionValidationContollerMvcTest {

	MockMvc mockMvc;

	@Mock
	AuthorizationService authorizationService;

	@Mock
	UserAccountRoleService userAccountRoleService;

	@InjectMocks
	ActionValidationContoller actionValidationContoller;

	@BeforeEach
	void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(actionValidationContoller).build();
	}

	@Test
	void validateAction() throws Exception {
		ActionValidationRequest request = TestConfiguration.getActionValidationRequest();

		mockMvc.perform(MockMvcRequestBuilders.post("/users/validate-action")
				.content(TestConfiguration.asJsonString(request))
				.header(ContextFields.USEREMAIL, "admin@digitalrealty.com")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void validateRole() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/users/validate-role/" + TestConfiguration.roleId)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isNoContent());
	}
}
