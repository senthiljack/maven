package com.digitalrealty.gapi.user.service;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jms.core.JmsTemplate;

import com.digitalrealty.gapi.messaging.user.MaintainUserMessage;
import com.digitalrealty.gapi.user.TestConfiguration;
import com.digitalrealty.gapi.user.configuration.MessagingConfig;

@ExtendWith(MockitoExtension.class)
public class JmsUserServiceTest {

	@Mock
	MessagingConfig messagingConfig;

	@Mock
	JmsTemplate jmsTemplate;

	@InjectMocks
	JmsUserService jmsUserService;

	@Test
	public void sendMessageTest() {
		Mockito.doNothing().when(jmsTemplate).convertAndSend(Mockito.anyString(), Mockito.any(MaintainUserMessage.class));
		when(messagingConfig.getMaintainUserQueue()).thenReturn("");

		String userId = jmsUserService.sendMessage(TestConfiguration.getMaintainUserMessage());

		assertThat(userId).isEqualTo(TestConfiguration.userId.toString());
		verify(jmsTemplate, times(1)).convertAndSend(Mockito.anyString(), Mockito.any(MaintainUserMessage.class));
	}
}
